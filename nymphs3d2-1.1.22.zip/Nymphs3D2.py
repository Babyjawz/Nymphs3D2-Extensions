"""
Live Blender addon implementation for Nymphs3D2.
"""

bl_info = {
    "name": "Nymphs3D2",
    "author": "Nymphs3D",
    "version": (1, 1, 22),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Nymphs",
    "description": "Blender client for local or remote Nymphs3D backends",
    "category": "3D View",
}

import base64
import atexit
import json
import os
import queue
import re
import shlex
import shutil
import subprocess
import tempfile
import threading
import textwrap
import time
from dataclasses import dataclass
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)


LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}
EVENT_QUEUE = queue.Queue()
PROCESS_LOCK = threading.Lock()
MANAGED_BACKENDS = {}
MANAGED_BACKEND_TARGETS = {}
ATEXIT_REGISTERED = False
STAGE_LINE = re.compile(r"STAGE:\s*([A-Za-z0-9_]+)")
PROGRESS_LINE = re.compile(r"PROGRESS:\s*([A-Za-z0-9_ -]+)\s+(\d+)/(\d+)")
GPU_REFRESH_SECONDS = 2.0
SERVER_POLL_SECONDS = 6.0
SERVER_POLL_FAST_SECONDS = 2.0
ACTIVE_POLL_IDLE_SECONDS = 8.0
ACTIVE_POLL_BUSY_SECONDS = 1.5
ACTIVE_POLL_UNAVAILABLE_SECONDS = 15.0
ACTIVE_POLL_DIRECT_JOB_SECONDS = 0.75
LOG_PREFIX_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[^\|]*\|\s*[A-Z]+\s*\|\s*(?:stdout|stderr|[^|]+)\s*\|\s*")
LOCAL_SHAPE_OUTPUT_DIRNAME = "nymphs3d2_shape_outputs"

DEFAULT_WSL_DISTRO = "Nymphs3D2"
DEFAULT_WSL_USER = "nymphs3d"
DEFAULT_REPO_2MV_PATH = "~/Hunyuan3D-2"
DEFAULT_REPO_21_PATH = "~/Hunyuan3D-2.1"
DEFAULT_REPO_N2D2_PATH = "~/Nymphs2D2"
DEFAULT_N2D2_MODEL_ID = "Tongyi-MAI/Z-Image-Turbo"
DEFAULT_N2D2_MODEL_VARIANT = ""
WSL_DISTRO_ITEMS = []
SERVICE_LABELS = {
    "2mv": "Hunyuan 2mv",
    "21": "Hunyuan 2.1",
    "n2d2": "Nymphs2D",
}
SERVICE_PROP_PREFIXES = {
    "2mv": "service_2mv",
    "21": "service_21",
    "n2d2": "service_n2d2",
}
SERVICE_ORDER = ("2mv", "n2d2", "21")


@dataclass
class ImportEvent:
    scene_name: str
    mesh_path: str
    source_object_name: str = ""


def _active_state(scene_name):
    scene = bpy.data.scenes.get(scene_name)
    if scene is None:
        return None
    return getattr(scene, "nymphs3d2v2_state", None)


def _touch_ui():
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return
    for window in wm.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _sync_shape_texture_state(state):
    if state is None:
        return
    if not bool(getattr(state, "server_supports_texture", False)):
        state.shape_generate_texture = False


def _launch_backend_label(state):
    if state.launch_backend == "BACKEND_21":
        return "2.1"
    return "2mv"


def _service_prefix(service_key):
    return SERVICE_PROP_PREFIXES[service_key]


def _service_prop_name(service_key, suffix):
    return f"{_service_prefix(service_key)}_{suffix}"


def _service_get(state, service_key, suffix, default=None):
    return getattr(state, _service_prop_name(service_key, suffix), default)


def _service_changes(service_key, **changes):
    return {
        _service_prop_name(service_key, key): value
        for key, value in changes.items()
    }


def _selected_3d_service_key(state):
    return "21" if state.launch_backend == "BACKEND_21" else "2mv"


def _service_port(state, service_key):
    value = (_service_get(state, service_key, "port", "") or "").strip()
    if value:
        return value
    if service_key == "21":
        return "8081"
    if service_key == "n2d2":
        return "8090"
    return "8080"


def _n2d2_model_family(model_id: str | None) -> str:
    normalized = (model_id or DEFAULT_N2D2_MODEL_ID).strip().lower()
    if "z-image" in normalized:
        return "zimage"
    return "generic"


def _n2d2_default_dtype(model_id: str | None) -> str:
    if _n2d2_model_family(model_id) == "zimage":
        return "bfloat16"
    return "float16"


def _service_api_root(state, service_key):
    return f"http://127.0.0.1:{_service_port(state, service_key)}"


def _service_enabled(state, service_key):
    return bool(_service_get(state, service_key, "enabled", False))


def _schedule_event_loop():
    if not bpy.app.timers.is_registered(_drain_events):
        bpy.app.timers.register(_drain_events, first_interval=0.0)


def _emit_status(scene_name, **changes):
    EVENT_QUEUE.put(("status", scene_name, changes))
    _schedule_event_loop()


def _emit_import(scene_name, mesh_path, source_object_name=""):
    EVENT_QUEUE.put(("import", ImportEvent(scene_name, mesh_path, source_object_name), None))
    _schedule_event_loop()


def _emit_service_status(scene_name, service_key, **changes):
    payload = _service_changes(service_key, **changes)
    state = _active_state(scene_name)
    if state is not None and service_key == _selected_3d_service_key(state):
        mirrored = {}
        if "launch_state" in changes:
            mirrored["launch_state"] = changes["launch_state"]
        if "launch_detail" in changes:
            mirrored["launch_detail"] = changes["launch_detail"]
        payload.update(mirrored)
    _emit_status(scene_name, **payload)


def _drain_events():
    processed = False
    while True:
        try:
            kind, payload_a, payload_b = EVENT_QUEUE.get_nowait()
        except queue.Empty:
            break

        processed = True
        if kind == "status":
            state = _active_state(payload_a)
            if state is not None:
                for key, value in payload_b.items():
                    setattr(state, key, value)
                _sync_shape_texture_state(state)
        elif kind == "import":
            _import_result(payload_a)

    if processed:
        _touch_ui()

    if not EVENT_QUEUE.empty():
        return 0.1

    for scene in bpy.data.scenes:
        state = getattr(scene, "nymphs3d2v2_state", None)
        if state is not None and (
            state.is_busy or state.launch_state in {"Launching", "Stopping"}
        ):
            return 0.2

    return None


def _normalize_api_root(raw_value):
    value = (raw_value or "").strip()
    if not value:
        raise RuntimeError("API URL is required.")
    return value.rstrip("/")


def _online_access_enabled():
    value = getattr(bpy.app, "online_access", None)
    if value is not None:
        return bool(value)
    return True


def _require_network_access(api_root):
    parsed = urlparse(api_root)
    hostname = (parsed.hostname or "").strip().lower()
    if hostname and hostname not in LOCAL_HOSTS and not _online_access_enabled():
        raise RuntimeError("Enable Blender online access before using a remote API URL.")


def _http_call(method, url, payload=None, timeout=10):
    body = None
    headers = {}
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    request = Request(url=url, data=body, headers=headers, method=method)
    try:
        with urlopen(request, timeout=timeout) as response:
            return response.status, response.headers.get("Content-Type", ""), response.read()
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"HTTP {exc.code}: {detail or exc.reason}") from exc
    except URLError as exc:
        parsed = urlparse(url)
        host = parsed.hostname or "unknown-host"
        port = parsed.port
        target = f"{host}:{port}" if port else host
        if host in LOCAL_HOSTS:
            raise RuntimeError(
                f"Could not reach local server at {target}. Start the backend in Nymphs Server or check the configured port."
            ) from exc
        raise RuntimeError(f"Network error reaching {target}: {exc.reason}") from exc


def _json_call(method, url, payload=None, timeout=10):
    _, _, body = _http_call(method, url, payload=payload, timeout=timeout)
    try:
        return json.loads(body.decode("utf-8"))
    except Exception as exc:
        raise RuntimeError("Server returned invalid JSON.") from exc


def _format_progress_text(current=None, total=None, percent=None):
    if current is not None and total:
        return f"{current}/{total}"
    if percent is not None:
        try:
            return f"{float(percent):.0f}%"
        except Exception:
            return str(percent)
    return ""


def _stage_label(stage):
    labels = {
        "startup": "Starting server",
        "request_received": "Request Received",
        "loading_input_image": "Loading Input",
        "loading_input_mesh": "Loading Mesh",
        "normalizing_mesh": "Normalizing Mesh",
        "loading_shape_pipeline": "Loading Shape",
        "sampling_shape": "Generating Shape",
        "shape_ready": "Shape Ready",
        "loading_texture_pipeline": "Loading Texture",
        "generating_texture": "Generating Texture",
        "texture": "Generating Texture",
        "texture_ready": "Texture Ready",
        "exporting_mesh": "Exporting Mesh",
        "exporting_textured_mesh": "Exporting Textured Mesh",
        "failed": "Failed",
    }
    if not stage:
        return ""
    return labels.get(stage, stage.replace("_", " ").title())


def _launch_21_shape_enabled(state):
    return not bool(getattr(state, "launch_texture_only", False))


def _launch_21_texture_enabled(state):
    if bool(getattr(state, "launch_texture_only", False)):
        return True
    return bool(getattr(state, "launch_texture_support", True))


def _launch_21_texture_only(state):
    return bool(getattr(state, "launch_texture_only", False))


def _on_launch_texture_only_changed(self, context):
    if bool(getattr(self, "launch_texture_only", False)):
        # Texture-only mode is always a texture-capable 2.1 launch.
        self.launch_texture_support = True


def _resolve_file_path(raw_path):
    path = (raw_path or "").strip()
    if not path:
        return ""

    if path.startswith("//"):
        blend_dir = os.path.dirname(bpy.data.filepath)
        if blend_dir:
            path = os.path.join(blend_dir, path[2:])

    return bpy.path.abspath(path)


def _file_to_base64(raw_path):
    path = _resolve_file_path(raw_path)
    if not path or not os.path.exists(path):
        raise RuntimeError(f"Missing file: {raw_path}")
    with open(path, "rb") as handle:
        return base64.b64encode(handle.read()).decode("utf-8")


def _parse_optional_seed(raw_value):
    value = (raw_value or "").strip()
    if not value:
        return None
    try:
        return int(value)
    except ValueError as exc:
        raise RuntimeError("Seed must be blank or a whole number.") from exc


def _sanitize_name_fragment(value, fallback="result"):
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", (value or "").strip()).strip("-._")
    return cleaned[:48] or fallback


def _shape_output_dir():
    path = os.path.join(tempfile.gettempdir(), LOCAL_SHAPE_OUTPUT_DIRNAME)
    os.makedirs(path, exist_ok=True)
    return path


def _shape_output_path(source_object_name=""):
    stamp = time.strftime("%Y%m%d-%H%M%S")
    stem = _sanitize_name_fragment(source_object_name, fallback="shape")
    candidate = os.path.join(_shape_output_dir(), f"{stamp}-{stem}.glb")
    if not os.path.exists(candidate):
        return candidate
    return os.path.join(_shape_output_dir(), f"{stamp}-{stem}-{int(time.time() * 1000) % 100000}.glb")


def _clear_folder_contents(folder_path):
    target = (folder_path or "").strip()
    if not target:
        raise RuntimeError("No folder is available yet.")
    if not os.path.isdir(target):
        raise RuntimeError(f"Folder does not exist: {target}")
    for entry in os.scandir(target):
        if entry.is_dir(follow_symlinks=False):
            shutil.rmtree(entry.path)
        else:
            os.unlink(entry.path)


def _to_blender_accessible_path(state, raw_path):
    path = (raw_path or "").strip()
    if not path:
        return ""
    if os.name != "nt":
        return path
    if path.startswith("\\\\wsl.localhost\\"):
        return path
    if not path.startswith("/"):
        return path
    distro = _resolved_wsl_distro_name(state)
    windows_path = path.replace("/", "\\")
    return f"\\\\wsl.localhost\\{distro}{windows_path}"


def _build_imagegen_payload(state):
    prompt = state.imagegen_prompt.strip()
    if not prompt:
        raise RuntimeError("Enter an image-generation prompt first.")

    payload = {
        "mode": "txt2img",
        "prompt": prompt,
        "negative_prompt": state.imagegen_negative_prompt.strip(),
        "width": int(state.imagegen_width),
        "height": int(state.imagegen_height),
        "steps": int(state.imagegen_steps),
        "guidance_scale": float(state.imagegen_guidance_scale),
    }
    seed = _parse_optional_seed(state.imagegen_seed)
    if seed is not None:
        payload["seed"] = seed
    return payload


def _export_selected_mesh_base64(context, export_format="glb"):
    selected_meshes = [obj for obj in context.selected_objects if obj.type == "MESH"]
    if not selected_meshes:
        raise RuntimeError("Select a mesh object first.")

    active_object = context.active_object
    source_object = active_object if active_object in selected_meshes else selected_meshes[0]
    export_format = (export_format or "glb").strip().lower()
    if export_format not in {"glb", "obj"}:
        raise RuntimeError(f"Unsupported mesh export format: {export_format}")
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=f".{export_format}")
    temp_file.close()
    temp_mtl = os.path.splitext(temp_file.name)[0] + ".mtl"
    view_layer = context.view_layer
    previous_active = view_layer.objects.active
    previous_selection = list(context.selected_objects)
    try:
        bpy.ops.object.select_all(action="DESELECT")
        source_object.select_set(True)
        view_layer.objects.active = source_object
        if export_format == "obj":
            if hasattr(bpy.ops.wm, "obj_export"):
                bpy.ops.wm.obj_export(
                    filepath=temp_file.name,
                    export_selected_objects=True,
                    export_materials=False,
                )
            elif hasattr(bpy.ops.export_scene, "obj"):
                bpy.ops.export_scene.obj(
                    filepath=temp_file.name,
                    use_selection=True,
                    use_materials=False,
                )
            else:
                raise RuntimeError("OBJ export is not available in this Blender build.")
        else:
            bpy.ops.export_scene.gltf(filepath=temp_file.name, use_selection=True)
        with open(temp_file.name, "rb") as handle:
            return base64.b64encode(handle.read()).decode("utf-8"), source_object.name
    finally:
        bpy.ops.object.select_all(action="DESELECT")
        for obj in previous_selection:
            if obj and obj.name in bpy.data.objects:
                obj.select_set(True)
        if previous_active and previous_active.name in bpy.data.objects:
            view_layer.objects.active = previous_active
        if os.path.exists(temp_file.name):
            os.unlink(temp_file.name)
        if os.path.exists(temp_mtl):
            os.unlink(temp_mtl)


def _build_shape_payload(state):
    payload = {
        "octree_resolution": state.mesh_detail,
        "num_inference_steps": state.detail_passes,
        "guidance_scale": state.reference_strength,
        "remove_background": state.auto_remove_background,
        "texture": state.shape_generate_texture,
    }

    if state.shape_workflow == "TEXT":
        prompt = state.prompt.strip()
        if not prompt:
            raise RuntimeError("Enter a text prompt first.")
        payload["text"] = prompt
        return payload

    if state.shape_workflow == "IMAGE":
        payload["image"] = _file_to_base64(state.image_path)
        if state.prompt.strip():
            payload["text"] = state.prompt.strip()
        return payload

    if state.shape_workflow == "MULTIVIEW":
        views = {
            "mv_image_front": state.mv_front,
            "mv_image_back": state.mv_back,
            "mv_image_left": state.mv_left,
            "mv_image_right": state.mv_right,
        }
        encoded = {}
        for key, raw_path in views.items():
            if raw_path.strip():
                encoded[key] = _file_to_base64(raw_path)
        if "mv_image_front" not in encoded:
            raise RuntimeError("A front image is required for multiview mode.")
        payload.update(encoded)
        if state.prompt.strip():
            payload["text"] = state.prompt.strip()
        return payload

    raise RuntimeError(f"Unsupported shape workflow: {state.shape_workflow}")


def _build_texture_payload(state, mesh_b64, mesh_format="glb"):
    if not mesh_b64:
        raise RuntimeError("Selected mesh export failed.")

    payload = {
        "mesh": mesh_b64,
        "mesh_format": mesh_format,
        "texture": True,
        "remove_background": state.auto_remove_background,
    }
    payload.update(_texture_option_payload(state, include_use_remesh=True))

    if state.image_path.strip():
        payload["image"] = _file_to_base64(state.image_path)
    elif state.prompt.strip():
        payload["text"] = state.prompt.strip()
    else:
        raise RuntimeError("Texture mode needs either an image or a text prompt.")

    return payload


def _texture_option_payload(state, include_use_remesh=False):
    payload = {
        "face_count": int(state.texture_face_limit),
    }

    if state.launch_backend == "BACKEND_21":
        payload["max_num_view"] = int(state.texture_max_views)
        payload["texture_resolution"] = int(state.texture_resolution)
        if include_use_remesh:
            payload["use_remesh"] = bool(state.texture_use_remesh)
    else:
        payload["texture_resolution"] = int(state.texture_resolution_2mv)

    return payload


def _summarize_server_info(info):
    backend_name = str(info.get("backend", "")).strip()
    if backend_name == "Nymphs2D2" or "supported_modes" in info:
        configured_model_id = info.get("configured_model_id", "unknown")
        loaded_model_id = info.get("loaded_model_id") or "not loaded"
        device = info.get("device", "unknown")
        dtype = info.get("dtype", "unknown")
        supported_modes = info.get("supported_modes") or []
        modes_text = ",".join(str(mode) for mode in supported_modes) if supported_modes else "none"
        return (
            f"Nymphs2D2 | cfg={configured_model_id} | loaded={loaded_model_id} | "
            f"{device}/{dtype} | modes={modes_text}"
        )

    status = info.get("status", "unknown")
    model_path = info.get("model_path", "unknown")
    subfolder = info.get("subfolder", "unknown")
    capabilities = _server_capabilities_from_info(info)
    return (
        f"{status} | {model_path} | {subfolder} | "
        f"shape={capabilities['shape']} | tex={capabilities['texture']} | "
        f"retexture={capabilities['retexture']} | mv={capabilities['multiview']} | "
        f"text={capabilities['text']}"
    )


def _backend_family(info):
    backend_name = str(info.get("backend", "")).strip().lower()
    if backend_name == "nymphs2d2":
        return "Nymphs2D2"
    blob = f"{info.get('model_path', '')} {info.get('subfolder', '')}".lower()
    if "2.1" in blob:
        return "2.1"
    if "2mv" in blob or "mv" in blob:
        return "2mv"
    if "hunyuan3d-2" in blob:
        return "2.0"
    return "Unknown"


def _server_capabilities_from_info(info):
    family = _backend_family(info)
    texture_only = bool(info.get("texture_only", False))
    text_enabled = bool(info.get("enable_t23d", False))
    retexture_enabled = bool(info.get("mesh_retexture", False))

    if family in {"2mv", "2.0"}:
        texture_enabled = bool(info.get("enable_tex", False))
        if not retexture_enabled:
            retexture_enabled = texture_enabled
        return {
            "family": family,
            "shape": not texture_only,
            "texture": texture_enabled,
            "retexture": retexture_enabled,
            "multiview": True,
            "text": text_enabled,
            "texture_only": texture_only,
        }

    if family == "2.1":
        texture_enabled = bool(info.get("enable_tex", True))
        return {
            "family": family,
            "shape": not texture_only,
            "texture": texture_enabled,
            "retexture": retexture_enabled,
            "multiview": False,
            "text": text_enabled,
            "texture_only": texture_only,
        }

    if family == "Nymphs2D2":
        return {
            "family": family,
            "shape": False,
            "texture": False,
            "retexture": False,
            "multiview": False,
            "text": False,
            "texture_only": False,
        }

    return {
        "family": family,
        "shape": not texture_only,
        "texture": False,
        "retexture": retexture_enabled,
        "multiview": False,
        "text": text_enabled,
        "texture_only": texture_only,
    }


def _fallback_server_capabilities(state):
    family = _launch_backend_label(state)
    if family == "2.1":
        texture_only = _launch_21_texture_only(state)
        texture_enabled = _launch_21_texture_enabled(state)
        return {
            "family": family,
            "shape": not texture_only,
            "texture": texture_enabled,
            "retexture": texture_enabled,
            "multiview": False,
            "text": bool(state.launch_text_bridge) and not texture_only,
            "texture_only": texture_only,
        }
    if family == "Nymphs2D2":
        return {
            "family": family,
            "shape": False,
            "texture": False,
            "retexture": False,
            "multiview": False,
            "text": False,
            "texture_only": False,
        }
    return {
        "family": family,
        "shape": True,
        "texture": bool(state.launch_texture_support),
        "retexture": bool(state.launch_texture_support),
        "multiview": True,
        "text": bool(state.launch_text_bridge),
        "texture_only": False,
    }


def _preferred_texture_mesh_format(state, caps):
    if caps["family"] == "2.1" and (caps["texture_only"] or _launch_21_texture_only(state)):
        return "obj"
    return "glb"


def _state_server_capabilities(state):
    capabilities = {
        "family": state.backend_family,
        "shape": bool(state.server_supports_shape),
        "texture": bool(state.server_supports_texture),
        "retexture": bool(state.server_supports_retexture),
        "multiview": bool(state.server_supports_multiview),
        "text": bool(state.server_supports_text),
        "texture_only": bool(state.server_texture_only),
    }
    if state.backend_summary in {"Unavailable", "Not checked", ""} and state.launch_state in {"Launching", "Running"}:
        return _fallback_server_capabilities(state)
    if capabilities["family"] == "Unknown" and state.launch_state in {"Launching", "Running"}:
        return _fallback_server_capabilities(state)
    return capabilities


def _normalized_panel_text(text):
    return " ".join((text or "").strip().lower().split())


def _scroll_text(text, window=42, step_seconds=0.6, gap="   "):
    cleaned = (text or "").strip()
    if len(cleaned) <= window:
        return cleaned
    cycle = cleaned + gap
    offset = int(time.monotonic() / step_seconds) % len(cycle)
    wrapped = cycle + cleaned + gap
    return wrapped[offset:offset + window]


def _format_elapsed_time(started_at):
    try:
        started = float(started_at or 0.0)
    except Exception:
        return ""
    if started <= 0.0:
        return ""
    elapsed = max(0, int(time.time() - started))
    hours, remainder = divmod(elapsed, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"


def _is_hidden_stage(stage):
    normalized = (stage or "").strip().lower()
    return normalized in {
        "",
        "completed",
        "job complete",
        "server boot complete",
        "server ready",
        "starting server",
        "launch requested",
    }


def _progress_lines(state):
    active_status = (state.task_status or "").lower()
    has_live_task = active_status in {"processing", "queued"}
    if not state.is_busy and not has_live_task:
        return "", "", ""
    if state.waiting_for_backend_progress:
        return (
            "Request Sent",
            "Waiting for backend progress...",
            "",
        )
    if active_status not in {"processing", "queued"}:
        if state.is_busy:
            return (
                "Request Sent",
                "Waiting for backend progress...",
                "",
            )
        return "", "", ""
    stage = (state.task_stage or "").strip()
    detail = (state.task_detail or state.task_message or "").strip()
    progress = (state.task_progress or "").strip()
    if _is_hidden_stage(stage):
        return (
            "Request Sent",
            "Waiting for backend progress...",
            "",
        )
    return (
        stage or "Working",
        detail,
        progress,
    )


def _imagegen_progress_lines(state):
    active_status = (state.imagegen_task_status or "").lower()
    has_live_task = active_status in {"processing", "queued"}
    elapsed = _format_elapsed_time(getattr(state, "imagegen_started_at", 0.0))
    if not state.imagegen_is_busy and not has_live_task:
        return "", "", ""
    stage = (state.imagegen_task_stage or "").strip()
    detail = (state.imagegen_task_detail or state.imagegen_status_text or "").strip()
    progress = (state.imagegen_task_progress or "").strip()
    if active_status not in {"processing", "queued"}:
        if state.imagegen_is_busy:
            progress = f"Elapsed {elapsed}" if elapsed else ""
            return "Running Inference", detail or "Waiting for image backend progress...", progress
        return "", "", ""
    if _is_hidden_stage(stage):
        progress = f"Elapsed {elapsed}" if elapsed else progress
        return "Running Inference", detail or "Waiting for image backend progress...", progress

    stage_key = stage.strip().lower()
    if stage_key in {"generating image", "generating_image"}:
        progress = f"Elapsed {elapsed}" if elapsed else ""
        return "Running Inference", detail or "Running image model inference...", progress
    return stage or "Generating Image", detail, progress


def _server_panel_job_lines(state):
    if state.launch_state == "Launching":
        return (
            state.task_stage or "Launch Requested",
            state.launch_detail or "Waiting for backend startup...",
            state.task_progress or "",
        )
    if state.launch_state == "Stopping":
        return ("Stopping", state.launch_detail or "Stopping backend...", "")
    if state.waiting_for_backend_progress:
        return "Request Sent", "Waiting for backend progress...", ""
    lines = _progress_lines(state)
    if any(lines):
        return lines
    if state.is_busy:
        return "Request Sent", "Waiting for backend progress...", ""
    image_lines = _imagegen_progress_lines(state)
    if any(image_lines):
        return image_lines
    fallback = _fallback_running_service(state)
    if fallback is not None:
        service_key, service_status, detail = fallback
        return f"{_service_display_name(service_key)} {service_status}", detail, ""
    return "", "", ""


def _server_status_line(state):
    backend_label = _backend_display_name(state.backend_family)
    if backend_label == "Unknown":
        backend_label = _backend_display_name(_launch_backend_label(state))
    active_status = (state.task_status or "").lower()
    image_status = (state.imagegen_task_status or "").lower()
    active_services = _active_service_entries(state)
    if state.launch_state == "Launching":
        return f"{backend_label} Launching"
    if state.launch_state == "Stopping":
        return "Stopping"
    if active_status == "processing":
        return f"{backend_label} Busy"
    if active_status == "queued" or state.waiting_for_backend_progress:
        return f"{backend_label} Submitting"
    if image_status == "processing":
        return f"{SERVICE_LABELS['n2d2']} Busy"
    if image_status == "queued" or state.imagegen_is_busy:
        return f"{SERVICE_LABELS['n2d2']} Submitting"
    if len(active_services) > 1:
        service_states = {service_status for _service_key, service_status in active_services}
        if service_states == {"Ready"}:
            return f"{len(active_services)} Runtimes Ready"
        if service_states <= {"Ready", "Running"}:
            return f"{len(active_services)} Runtimes Active"
        if "Launching" in service_states:
            return "Runtimes Launching"
        if "Stopping" in service_states:
            return "Runtimes Stopping"
        return f"{len(active_services)} Runtimes Active"
    if len(active_services) == 1:
        service_key, service_status = active_services[0]
        return f"{_service_display_name(service_key)} {service_status}"
    return "Server stopped"


def _fallback_running_service(state):
    primary_key = _selected_3d_service_key(state)
    for service_key in SERVICE_ORDER:
        if service_key == primary_key:
            continue
        service_status = _service_status_line(state, service_key)
        summary = (_service_get(state, service_key, "backend_summary", "Unavailable") or "").strip()
        detail = (_service_get(state, service_key, "launch_detail", "") or "").strip()
        if service_status == "Stopped" and summary in {"", "Unavailable", "Not checked"} and not _backend_is_alive(service_key):
            continue
        detail_text = detail or summary or service_status
        return service_key, service_status, detail_text
    return None


def _active_service_entries(state):
    entries = []
    for service_key in SERVICE_ORDER:
        launch_state = _service_get(state, service_key, "launch_state", "Stopped")
        summary = (_service_get(state, service_key, "backend_summary", "Unavailable") or "").strip()
        if launch_state == "Launching":
            service_status = "Launching"
        elif launch_state == "Stopping":
            service_status = "Stopping"
        elif summary and summary not in {"Unavailable", "Not checked", ""}:
            service_status = "Ready"
        elif _backend_is_alive(service_key):
            service_status = "Running"
        else:
            service_status = "Stopped"
        if service_status == "Stopped" and summary in {"", "Unavailable", "Not checked"} and not _backend_is_alive(service_key):
            continue
        entries.append((service_key, service_status))
    return entries


def _active_service_summaries(state):
    return [f"{_service_display_name(service_key)} {service_status}" for service_key, service_status in _active_service_entries(state)]


def _current_vram_estimate(state):
    backend = _launch_backend_label(state)
    flashvdm = bool(state.launch_flashvdm)
    turbo = bool(state.launch_turbo)
    low_vram = bool(state.launch_low_vram)
    if state.shape_workflow == "TEXT" and state.prompt.strip():
        input_mode = "text_prompt"
    elif state.shape_workflow == "MULTIVIEW":
        input_mode = "multiview"
    else:
        input_mode = "single_image"

    if backend == "Nymphs2D2":
        estimate = "Varies by model"
        basis = "Basis: backend-configured model"
        mode = "2D image generation"
        caveat = "2D image models are loaded through Nymphs2D2, not the 3D pipeline."
        return estimate, basis, mode, caveat

    if backend == "2.1":
        if _launch_21_texture_only(state):
            estimate = "21 GB"
            basis = "Basis: official"
            mode = "Texture only"
            caveat = (
                "Low VRAM may help fit, but the official texture figure is still 21 GB."
                if low_vram
                else "Official 2.1 texture figure."
            )
            return estimate, basis, mode, caveat
        texture_enabled = _launch_21_texture_enabled(state)
        if texture_enabled and state.shape_generate_texture:
            estimate = "29 GB total"
            basis = "Basis: official"
            mode = "Shape + texture"
            caveat = (
                "Low VRAM may help fit; no exact official replacement figure."
                if low_vram
                else "Low VRAM is recommended on 16 GB GPUs."
            )
            return estimate, basis, mode, caveat
        if input_mode == "text_prompt":
            estimate = "10-12 GB"
            basis = "Basis: official + inferred"
            mode = "Shape + text bridge"
            caveat = (
                "Low VRAM may help fit; bridge overhead is not separately published."
                if low_vram
                else "10 GB shape is official; bridge overhead is inferred."
            )
            return estimate, basis, mode, caveat
        estimate = "10 GB"
        basis = "Basis: official"
        mode = "Shape only"
        caveat = (
            "Low VRAM may reduce pressure, but no exact official number is published."
            if low_vram
            else "Official 2.1 shape figure."
        )
        return estimate, basis, mode, caveat

    texture = bool(state.launch_texture_support or state.shape_generate_texture)
    if texture:
        estimate = "16-24.5 GB total"
        basis = "Basis: official + inferred"
        mode = "Shape + texture"
        caveat = (
            "FlashVDM helps throughput, but texture mode still needs the larger VRAM budget."
            if flashvdm
            else "Texture mode is the main VRAM driver on 2mv."
        )
        return estimate, basis, mode, caveat
    if input_mode == "text_prompt":
        estimate = "10-12 GB"
        basis = "Basis: inferred"
        mode = "Shape + text bridge"
        caveat = "2mv text bridge overhead is inferred from mixed workflow usage."
        return estimate, basis, mode, caveat
    estimate = "9-12 GB"
    basis = "Basis: inferred"
    mode = "Shape only"
    caveat = "Turbo improves latency more than VRAM footprint." if turbo else "Standard 2mv shape mode."
    return estimate, basis, mode, caveat


def _active_task_snapshot(api_root):
    try:
        status_code, _, body = _http_call("GET", f"{api_root}/active_task", timeout=1.5)
        if status_code == 404:
            return {
                "status": "unsupported",
                "stage": "",
                "detail": "",
                "progress_text": "",
                "message": "",
            }
        data = json.loads(body.decode("utf-8"))
    except Exception:
        return {
            "status": "unavailable",
            "stage": "",
            "detail": "",
            "progress_text": "",
            "message": "",
        }

    stage = data.get("stage") or ""
    detail = data.get("detail") or data.get("message") or ""
    message = data.get("message") or ""

    return {
        "status": data.get("status", "idle"),
        "stage": _stage_label(stage),
        "detail": detail,
        "progress_text": _format_progress_text(
            current=data.get("progress_current"),
            total=data.get("progress_total"),
            percent=data.get("progress_percent"),
        ),
        "message": message,
    }


def _managed_backend(service_key=None):
    with PROCESS_LOCK:
        if service_key is None:
            return dict(MANAGED_BACKENDS)
        return MANAGED_BACKENDS.get(service_key)


def _managed_backend_target(service_key=None):
    with PROCESS_LOCK:
        if service_key is None:
            return dict(MANAGED_BACKEND_TARGETS)
        return MANAGED_BACKEND_TARGETS.get(service_key)


def _remember_backend(service_key, proc, target=None):
    with PROCESS_LOCK:
        MANAGED_BACKENDS[service_key] = proc
        MANAGED_BACKEND_TARGETS[service_key] = dict(target or {})


def _forget_backend(service_key=None, proc=None):
    with PROCESS_LOCK:
        if service_key is not None:
            current = MANAGED_BACKENDS.get(service_key)
            if proc is None or current is proc:
                MANAGED_BACKENDS.pop(service_key, None)
                MANAGED_BACKEND_TARGETS.pop(service_key, None)
            return

        if proc is None:
            MANAGED_BACKENDS.clear()
            MANAGED_BACKEND_TARGETS.clear()
            return

        doomed = [key for key, current in MANAGED_BACKENDS.items() if current is proc]
        for key in doomed:
            MANAGED_BACKENDS.pop(key, None)
            MANAGED_BACKEND_TARGETS.pop(key, None)


def _backend_is_alive(service_key=None):
    if service_key is None:
        return any(proc.poll() is None for proc in _managed_backend().values())
    proc = _managed_backend(service_key)
    return proc is not None and proc.poll() is None


def _shutdown_managed_backends():
    backends = _managed_backend()
    targets = _managed_backend_target()
    for service_key, proc in list(backends.items()):
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        _forget_backend(service_key=service_key, proc=proc)

        target = targets.get(service_key, {})
        stop_port = (target or {}).get("port") or "8080"
        _best_effort_stop_local(stop_port, target, service_key=service_key)


def _sync_local_api(state):
    state.api_root = _service_api_root(state, _selected_3d_service_key(state))


def _probe_gpu_host():
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,memory.total,memory.used,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=2,
            check=True,
        )
        row = result.stdout.strip().splitlines()[0]
        name, mem_total, mem_used, util = [part.strip() for part in row.split(",")]
        return {
            "name": name,
            "memory": f"{mem_used} / {mem_total} MB",
            "utilization": f"{util}%",
            "status": "Connected",
        }
    except Exception as exc:
        return {
            "name": "Unavailable",
            "memory": "Unavailable",
            "utilization": "Unavailable",
            "status": str(exc),
        }


def _shell_repo_path(raw_path):
    path = (raw_path or "").strip()
    if not path:
        return "~"
    if path.startswith("~/"):
        suffix = path[2:]
        if not suffix:
            return "$HOME"
        return f"$HOME/{shlex.quote(suffix)}"
    return shlex.quote(path)


def _installed_wsl_distro_items():
    names = []
    try:
        result = subprocess.run(
            ["wsl", "-l", "-q"],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                name = line.replace("\0", "").strip()
                if name:
                    names.append(name)
    except Exception:
        pass

    ordered = []
    seen = set()
    for candidate in [DEFAULT_WSL_DISTRO, *names]:
        name = (candidate or "").strip()
        if not name:
            continue
        lowered = name.lower()
        if lowered in seen:
            continue
        seen.add(lowered)
        description = (
            "Managed installer distro"
            if name == DEFAULT_WSL_DISTRO
            else f"Use installed WSL distro '{name}'"
        )
        ordered.append((name, name, description))

    if not ordered:
        ordered.append((DEFAULT_WSL_DISTRO, DEFAULT_WSL_DISTRO, "Managed installer distro"))

    WSL_DISTRO_ITEMS[:] = ordered
    return WSL_DISTRO_ITEMS


def _wsl_distro_items(_self, _context):
    return _installed_wsl_distro_items()


def _resolved_wsl_distro_name(state=None):
    if isinstance(state, dict):
        value = (state.get("wsl_distro_name", DEFAULT_WSL_DISTRO) or "").strip()
        return value or DEFAULT_WSL_DISTRO
    if state is None:
        return DEFAULT_WSL_DISTRO
    value = (getattr(state, "wsl_distro_name", DEFAULT_WSL_DISTRO) or "").strip()
    return value or DEFAULT_WSL_DISTRO


def _resolved_wsl_user_name(state=None):
    if isinstance(state, dict):
        value = (state.get("wsl_user_name", DEFAULT_WSL_USER) or "").strip()
        return value or DEFAULT_WSL_USER
    if state is None:
        return DEFAULT_WSL_USER
    value = (getattr(state, "wsl_user_name", DEFAULT_WSL_USER) or "").strip()
    return value or DEFAULT_WSL_USER


def _compose_wsl_invocation(shell, state=None):
    command = ["wsl", "-d", _resolved_wsl_distro_name(state)]
    user_name = _resolved_wsl_user_name(state)
    if user_name:
        command.extend(["-u", user_name])
    command.extend(["--", "bash", "-lc", shell])
    return command


def _compose_wsl_launch(state, service_key):
    port = _service_port(state, service_key)
    exports = (
        "export CUDA_HOME=/usr/local/cuda-13.0; "
        'export PATH="$CUDA_HOME/bin:$PATH"; '
        'export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"; '
    )

    if service_key == "n2d2":
        repo_path = state.repo_n2d2_path.strip() or DEFAULT_REPO_N2D2_PATH
        n2d2_model_id = state.n2d2_model_id.strip() or DEFAULT_N2D2_MODEL_ID
        n2d2_variant = state.n2d2_model_variant.strip() or DEFAULT_N2D2_MODEL_VARIANT
        n2d2_dtype = _n2d2_default_dtype(n2d2_model_id)
        n2d2_home = f"/home/{_resolved_wsl_user_name(state)}"
        hf_home = f"{n2d2_home}/.cache/huggingface"
        hf_cache = f"{hf_home}/hub"
        exports += (
            f"export HF_HOME={shlex.quote(hf_home)}; "
            f"export HF_HUB_CACHE={shlex.quote(hf_cache)}; "
            'export HF_HUB_DISABLE_XET=1; '
            f"export NYMPHS3D_HF_CACHE_DIR={shlex.quote(hf_cache)}; "
            'export NYMPHS2D2_DEVICE="cuda"; '
            f"export NYMPHS2D2_DTYPE={shlex.quote(n2d2_dtype)}; "
            f"export NYMPHS2D2_MODEL_ID={shlex.quote(n2d2_model_id)}; "
            f"export NYMPHS2D2_PORT={shlex.quote(port)}; "
        )
        if n2d2_variant:
            exports += f"export NYMPHS2D2_MODEL_VARIANT={shlex.quote(n2d2_variant)}; "
        parts = [
            "python",
            "api_server.py",
            "--host",
            "0.0.0.0",
            "--port",
            port,
        ]
    elif service_key == "21":
        repo_path = state.repo_21_path.strip() or DEFAULT_REPO_21_PATH
        texture_enabled = _launch_21_texture_enabled(state)
        texture_only = _launch_21_texture_only(state)
        parts = [
            "python",
            "-u",
            "api_server_tex.py" if texture_only else "api_server.py",
            "--host",
            "0.0.0.0",
            "--port",
            port,
            "--model_path",
            "tencent/Hunyuan3D-2.1",
            "--subfolder",
            "hunyuan3d-paintpbr-v2-1" if texture_only else "hunyuan3d-dit-v2-1",
        ]
        if not texture_only and not texture_enabled:
            parts.append("--disable_tex")
        if state.launch_text_bridge and not texture_only:
            parts.append("--enable_t23d")
        if state.launch_low_vram:
            parts.append("--low_vram_mode")
    else:
        repo_path = state.repo_2mv_path.strip() or DEFAULT_REPO_2MV_PATH
        subfolder = "hunyuan3d-dit-v2-mv-turbo" if state.launch_turbo else "hunyuan3d-dit-v2-mv"
        parts = [
            "python",
            "-u",
            "api_server_mv.py",
            "--host",
            "0.0.0.0",
            "--port",
            port,
            "--model_path",
            "tencent/Hunyuan3D-2mv",
            "--subfolder",
            subfolder,
            "--tex_model_path",
            "tencent/Hunyuan3D-2",
        ]
        if state.launch_texture_support:
            parts.append("--enable_tex")
        if state.launch_text_bridge:
            parts.append("--enable_t23d")
        if state.launch_flashvdm:
            parts.append("--enable_flashvdm")

    cmd = " ".join(shlex.quote(part) for part in parts)
    return f"{exports}cd {_shell_repo_path(repo_path)}; source .venv/bin/activate; {cmd}"


def _stop_shell_for_service(service_key, port):
    common = f'(command -v fuser >/dev/null 2>&1 && fuser -k {port}/tcp >/dev/null 2>&1) || true; '
    if service_key == "2mv":
        return (
            common +
            f'pkill -f "api_server_mv.py --host 0.0.0.0 --port {port}" >/dev/null 2>&1 || true; '
            'pkill -f "python -u api_server_mv.py" >/dev/null 2>&1 || true; '
            'pkill -f "python api_server_mv.py" >/dev/null 2>&1 || true'
        )
    if service_key == "21":
        return (
            common +
            f'pkill -f "api_server_tex.py --host 0.0.0.0 --port {port}" >/dev/null 2>&1 || true; '
            f'pkill -f "api_server.py --host 0.0.0.0 --port {port} --model_path tencent/Hunyuan3D-2.1" >/dev/null 2>&1 || true; '
            'pkill -f "python -u api_server_tex.py" >/dev/null 2>&1 || true; '
            'pkill -f "python -u api_server.py --host 0.0.0.0 --port" >/dev/null 2>&1 || true'
        )
    return (
        common +
        f'pkill -f "api_server.py --host 0.0.0.0 --port {port}" >/dev/null 2>&1 || true; '
        'pkill -f "Nymphs2D2/api_server.py" >/dev/null 2>&1 || true'
    )


def _best_effort_stop_local(port=None, state=None, service_key=None):
    if service_key is None:
        for key in SERVICE_ORDER:
            _best_effort_stop_local(_service_port(state, key) if state is not None else None, state, service_key=key)
        return

    port = (port or _service_port(state, service_key) or "8080").strip() or "8080"
    shell = _stop_shell_for_service(service_key, port)
    try:
        subprocess.run(
            _compose_wsl_invocation(shell, state),
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except Exception:
        return False
    return True


def _startup_hint(line):
    cleaned = (line or "").replace("\r", "").strip()
    if not cleaned:
        return None
    cleaned = LOG_PREFIX_RE.sub("", cleaned).strip()
    if "Uvicorn running on http://" in cleaned or "Application startup complete." in cleaned:
        return "Server ready"

    stage_match = STAGE_LINE.search(cleaned)
    if stage_match:
        return stage_match.group(1).replace("_", " ").title()

    progress_match = PROGRESS_LINE.search(cleaned)
    if progress_match:
        label = progress_match.group(1).strip()
        return f"{label} {progress_match.group(2)}/{progress_match.group(3)}"

    for token in ("Loading", "FlashVDM", "Texture", "Diffusion Sampling", "Volume Decoding"):
        if token in cleaned:
            return cleaned[:120]
    return None


def _backend_stdout_pump(scene_name, proc, service_key):
    stream = proc.stdout
    if stream is None:
        return
    try:
        for raw_line in stream:
            if _managed_backend(service_key) is not proc:
                break
            hint = _startup_hint(raw_line)
            if not hint:
                continue
            if hint == "Server ready":
                _emit_service_status(
                    scene_name,
                    service_key,
                    launch_state="Running",
                    launch_detail="Server ready",
                )
                state = _active_state(scene_name)
                if state is not None and service_key == _selected_3d_service_key(state):
                    _emit_status(scene_name, status_text="Local backend is ready.")
            else:
                _emit_service_status(scene_name, service_key, launch_detail=hint)
    except Exception:
        return


def _backend_lifecycle(scene_name, proc, service_key):
    exit_code = proc.wait()
    _forget_backend(service_key=service_key, proc=proc)
    state = "Stopped"
    message = "Server stopped."
    if exit_code not in (0, -15):
        message = f"Server exited with code {exit_code}."
    changes = {
        "launch_state": state,
        "launch_detail": message,
        "backend_summary": "Unavailable",
    }
    if service_key in {"2mv", "21"}:
        changes.update(
            {
                "backend_family": "Unknown",
                "server_supports_shape": False,
                "server_supports_texture": False,
                "server_supports_retexture": False,
                "server_supports_multiview": False,
                "server_supports_text": False,
                "server_texture_only": False,
            }
        )
    _emit_service_status(scene_name, service_key, **changes)


def _background_primary_probe(scene_name):
    state = _active_state(scene_name)
    if state is None:
        return
    api_root = _normalize_api_root(state.api_root)
    try:
        info = _json_call("GET", f"{api_root}/server_info", timeout=2)
        capabilities = _server_capabilities_from_info(info)
        _emit_status(
            scene_name,
            backend_summary=_summarize_server_info(info),
            backend_family=capabilities["family"],
            server_supports_shape=capabilities["shape"],
            server_supports_texture=capabilities["texture"],
            server_supports_retexture=capabilities["retexture"],
            server_supports_multiview=capabilities["multiview"],
            server_supports_text=capabilities["text"],
            server_texture_only=capabilities["texture_only"],
            launch_state="Running" if state.launch_state != "Stopping" else state.launch_state,
            launch_detail="Server ready",
        )
    except Exception as exc:
        changes = {
            "backend_summary": "Unavailable",
            "backend_family": "Unknown",
            "server_supports_shape": False,
            "server_supports_texture": False,
            "server_supports_retexture": False,
            "server_supports_multiview": False,
            "server_supports_text": False,
            "server_texture_only": False,
        }
        if state.launch_state == "Launching" and _backend_is_alive(_selected_3d_service_key(state)):
            changes["launch_detail"] = f"Waiting for /server_info at {api_root}"
            changes["status_text"] = f"Launch probe: {exc}"
        _emit_status(scene_name, **changes)


def _background_server_probe(scene_name, service_key):
    state = _active_state(scene_name)
    if state is None:
        return
    api_root = _normalize_api_root(_service_api_root(state, service_key))
    try:
        info = _json_call("GET", f"{api_root}/server_info", timeout=2)
        capabilities = _server_capabilities_from_info(info)
        _emit_service_status(
            scene_name,
            service_key,
            backend_summary=_summarize_server_info(info),
            backend_family=capabilities["family"],
            server_supports_shape=capabilities["shape"],
            server_supports_texture=capabilities["texture"],
            server_supports_retexture=capabilities["retexture"],
            server_supports_multiview=capabilities["multiview"],
            server_supports_text=capabilities["text"],
            server_texture_only=capabilities["texture_only"],
            launch_state=(
                "Running"
                if _service_get(state, service_key, "launch_state", "Stopped") != "Stopping"
                else "Stopping"
            ),
            launch_detail="Server ready",
        )
    except Exception as exc:
        changes = {
            "backend_summary": "Unavailable",
        }
        if service_key == _selected_3d_service_key(state):
            changes.update(
                {
                    "backend_family": "Unknown",
                    "server_supports_shape": False,
                    "server_supports_texture": False,
                    "server_supports_retexture": False,
                    "server_supports_multiview": False,
                    "server_supports_text": False,
                    "server_texture_only": False,
                }
            )
        if _service_get(state, service_key, "launch_state", "Stopped") == "Launching" and _backend_is_alive(service_key):
            changes["launch_detail"] = f"Waiting for /server_info at {api_root}"
            if service_key == _selected_3d_service_key(state):
                changes["status_text"] = f"Launch probe: {exc}"
        _emit_service_status(scene_name, service_key, **changes)


def _background_active_probe(scene_name):
    state = _active_state(scene_name)
    if state is None:
        return
    api_root = _normalize_api_root(state.api_root)
    snapshot = _active_task_snapshot(api_root)
    status = (snapshot.get("status") or "").lower()
    stage = snapshot.get("stage") or ""
    detail = snapshot.get("detail") or ""
    progress_text = snapshot.get("progress_text") or ""
    message = snapshot.get("message") or ""

    if status == "completed":
        changes = {
            "task_status": "idle",
            "task_stage": "",
            "task_detail": "",
            "task_progress": "",
            "task_message": "",
        }
        if not state.is_busy:
            changes["waiting_for_backend_progress"] = False
            changes["saw_real_backend_progress"] = False
        _emit_status(scene_name, **changes)
        return

    if state.is_busy and state.waiting_for_backend_progress:
        real_progress_arrived = (
            status == "processing"
            and not _is_hidden_stage(stage)
            and (bool(stage) or bool(detail) or bool(progress_text))
        )
        if not real_progress_arrived:
            return
        _emit_status(
            scene_name,
            waiting_for_backend_progress=False,
            saw_real_backend_progress=True,
        )

    if status not in {"processing", "queued"} or _is_hidden_stage(stage):
        if not state.is_busy:
            _emit_status(
                scene_name,
                task_status="idle",
                task_stage="",
                task_detail="",
                task_progress="",
                task_message="",
            )
        return

    _emit_status(
        scene_name,
        task_status=status,
        task_stage=stage,
        task_detail=detail,
        task_progress=progress_text,
        task_message=message,
    )


def _background_imagegen_probe(scene_name):
    state = _active_state(scene_name)
    if state is None:
        return
    api_root = _normalize_api_root(_service_api_root(state, "n2d2"))
    snapshot = _active_task_snapshot(api_root)
    status = (snapshot.get("status") or "").lower()
    stage = snapshot.get("stage") or ""
    detail = snapshot.get("detail") or ""
    progress_text = snapshot.get("progress_text") or ""

    if status in {"completed", "idle"}:
        if not state.imagegen_is_busy:
            _emit_status(
                scene_name,
                imagegen_task_status="idle",
                imagegen_task_stage="",
                imagegen_task_detail="",
                imagegen_task_progress="",
            )
        return

    if status not in {"processing", "queued"}:
        if not state.imagegen_is_busy:
            _emit_status(
                scene_name,
                imagegen_task_status="idle",
                imagegen_task_stage="",
                imagegen_task_detail="",
                imagegen_task_progress="",
            )
        return

    _emit_status(
        scene_name,
        imagegen_task_status=status,
        imagegen_task_stage=stage,
        imagegen_task_detail=detail,
        imagegen_task_progress=progress_text,
    )


def _server_probe_timer():
    interval = SERVER_POLL_SECONDS
    for scene in bpy.data.scenes:
        state = getattr(scene, "nymphs3d2v2_state", None)
        if state is None:
            continue
        threading.Thread(target=_background_primary_probe, args=(scene.name,), daemon=True).start()
        for service_key in SERVICE_ORDER:
            if _service_enabled(state, service_key) or _backend_is_alive(service_key):
                threading.Thread(
                    target=_background_server_probe,
                    args=(scene.name, service_key),
                    daemon=True,
                ).start()
            if _service_get(state, service_key, "launch_state", "Stopped") in {"Launching", "Stopping"}:
                interval = SERVER_POLL_FAST_SECONDS
        break
    return interval


def _active_probe_timer():
    interval = ACTIVE_POLL_IDLE_SECONDS
    for scene in bpy.data.scenes:
        state = getattr(scene, "nymphs3d2v2_state", None)
        if state is None:
            continue
        threading.Thread(target=_background_active_probe, args=(scene.name,), daemon=True).start()
        if state.imagegen_is_busy or _backend_is_alive("n2d2"):
            threading.Thread(target=_background_imagegen_probe, args=(scene.name,), daemon=True).start()
        status = (state.task_status or "").lower()
        image_status = (state.imagegen_task_status or "").lower()
        if state.is_busy:
            interval = ACTIVE_POLL_DIRECT_JOB_SECONDS
        elif state.imagegen_is_busy:
            interval = ACTIVE_POLL_DIRECT_JOB_SECONDS
        elif status in {"processing", "queued"}:
            interval = ACTIVE_POLL_BUSY_SECONDS
        elif image_status in {"processing", "queued"}:
            interval = ACTIVE_POLL_BUSY_SECONDS
        elif status in {"unsupported", "unavailable"}:
            interval = ACTIVE_POLL_UNAVAILABLE_SECONDS
        break
    return interval


def _gpu_probe_timer():
    for scene in bpy.data.scenes:
        state = getattr(scene, "nymphs3d2v2_state", None)
        if state is None:
            continue
        stats = _probe_gpu_host()
        state.gpu_name = stats["name"]
        state.gpu_memory = stats["memory"]
        state.gpu_utilization = stats["utilization"]
        state.gpu_status_message = stats["status"]
        break
    return GPU_REFRESH_SECONDS


def _import_result(event):
    before_names = set(bpy.data.objects.keys())
    bpy.ops.import_scene.gltf(filepath=event.mesh_path)
    imported_names = [name for name in bpy.data.objects.keys() if name not in before_names]

    if event.source_object_name and imported_names:
        source_object = bpy.data.objects.get(event.source_object_name)
        imported_object = bpy.data.objects.get(imported_names[0])
        if source_object is not None and imported_object is not None:
            imported_object.location = source_object.location
            imported_object.rotation_euler = source_object.rotation_euler
            imported_object.scale = source_object.scale
            source_object.hide_set(True)
            source_object.hide_render = True

    state = _active_state(event.scene_name)
    if state is not None:
        state.is_busy = False
        state.task_status = "idle"
        state.task_stage = ""
        state.task_detail = ""
        state.task_progress = ""
        state.task_message = ""
        state.waiting_for_backend_progress = False
        state.saw_real_backend_progress = False
        state.generation_request_finished_locally = True
        state.status_text = "Mesh imported into Blender."
        state.last_result = "Imported latest result"
        state.shape_output_path = event.mesh_path
        state.shape_output_dir = os.path.dirname(event.mesh_path) if event.mesh_path else ""


def _job_worker(scene_name, api_root, payload, source_object_name):
    try:
        _, content_type, body = _http_call(
            "POST",
            f"{api_root}/generate",
            payload=payload,
            timeout=1800,
        )
        if "json" in (content_type or "").lower():
            try:
                detail = json.loads(body.decode("utf-8"))
            except Exception:
                detail = body.decode("utf-8", errors="replace")
            raise RuntimeError(f"Expected mesh bytes, got JSON: {detail}")

        output_path = _shape_output_path(source_object_name)
        with open(output_path, "wb") as handle:
            handle.write(body)

        _emit_status(scene_name, status_text="Generation finished. Importing result...")
        _emit_import(scene_name, output_path, source_object_name)
    except Exception as exc:
        _emit_status(
            scene_name,
            is_busy=False,
            task_status="idle",
            task_stage="",
            task_detail="",
            task_progress="",
            task_message="",
            waiting_for_backend_progress=False,
            saw_real_backend_progress=False,
            generation_request_finished_locally=False,
            status_text=str(exc),
        )


def _imagegen_worker(scene_name, api_root, payload):
    try:
        detail = _json_call(
            "POST",
            f"{api_root}/generate",
            payload=payload,
            timeout=1800,
        )
        output_path = (detail.get("output_path") or "").strip()
        if not output_path:
            raise RuntimeError("Nymphs2D2 did not return an output path.")

        metadata_path = (detail.get("metadata_path") or "").strip()
        state = _active_state(scene_name)
        blender_output_path = _to_blender_accessible_path(state, output_path)
        blender_metadata_path = _to_blender_accessible_path(state, metadata_path)

        _emit_status(
            scene_name,
            imagegen_is_busy=False,
            imagegen_started_at=0.0,
            imagegen_status_text="Image generated and assigned to Image.",
            imagegen_task_status="idle",
            imagegen_task_stage="",
            imagegen_task_detail="",
            imagegen_task_progress="",
            imagegen_output_path=blender_output_path,
            imagegen_output_dir=os.path.dirname(blender_output_path) if blender_output_path else "",
            imagegen_metadata_path=blender_metadata_path,
            image_path=blender_output_path,
        )
    except Exception as exc:
        _emit_status(
            scene_name,
            imagegen_is_busy=False,
            imagegen_started_at=0.0,
            imagegen_status_text=str(exc),
            imagegen_task_status="idle",
            imagegen_task_stage="",
            imagegen_task_detail="",
            imagegen_task_progress="",
        )


class NymphsV2State(bpy.types.PropertyGroup):
    api_root: StringProperty(
        name="API URL",
        description="URL of the Nymphs3D backend API",
        default="http://127.0.0.1:8080",
    )
    launch_backend: EnumProperty(
        name="Backend",
        items=(
            ("BACKEND_2MV", "Hunyuan 2mv", "Launch the multiview Hunyuan shape backend"),
            ("BACKEND_21", "Hunyuan 2.1", "Launch the legacy single-image backend"),
        ),
        default="BACKEND_2MV",
    )
    service_2mv_enabled: BoolProperty(name="Enable Hunyuan 2mv", default=True)
    service_2mv_port: StringProperty(name="Hunyuan 2mv Port", default="8080")
    service_2mv_show: BoolProperty(default=False)
    service_2mv_launch_state: StringProperty(default="Stopped")
    service_2mv_launch_detail: StringProperty(default="Hunyuan 2mv server is not running.")
    service_2mv_backend_summary: StringProperty(default="Unavailable")
    service_21_enabled: BoolProperty(name="Enable 2.1", default=False)
    service_21_port: StringProperty(name="2.1 Port", default="8081")
    service_21_show: BoolProperty(default=False)
    service_21_launch_state: StringProperty(default="Stopped")
    service_21_launch_detail: StringProperty(default="2.1 server is not running.")
    service_21_backend_summary: StringProperty(default="Unavailable")
    service_n2d2_enabled: BoolProperty(name="Enable Nymphs2D", default=False)
    service_n2d2_port: StringProperty(name="Nymphs2D Port", default="8090")
    service_n2d2_show: BoolProperty(default=False)
    service_n2d2_launch_state: StringProperty(default="Stopped")
    service_n2d2_launch_detail: StringProperty(default="Nymphs2D server is not running.")
    service_n2d2_backend_summary: StringProperty(default="Unavailable")
    launch_shape_support: BoolProperty(
        name="Shape",
        default=True,
    )
    launch_texture_support: BoolProperty(
        name="Texture",
        default=True,
    )
    launch_texture_only: BoolProperty(
        name="Texture-Only Server",
        default=False,
        update=_on_launch_texture_only_changed,
    )
    launch_text_bridge: BoolProperty(
        name="Text Prompt Support",
        default=False,
    )
    launch_turbo: BoolProperty(
        name="Turbo",
        default=True,
    )
    launch_flashvdm: BoolProperty(
        name="FlashVDM",
        default=True,
    )
    launch_low_vram: BoolProperty(
        name="Low VRAM",
        default=True,
    )
    launch_open_terminal: BoolProperty(
        name="Open Terminal Window",
        default=False,
    )
    launch_port: StringProperty(
        name="Port",
        default="8080",
    )
    wsl_distro_name: EnumProperty(
        name="WSL Distro",
        description="Which installed WSL distro to target for local backend launch",
        items=_wsl_distro_items,
    )
    wsl_user_name: StringProperty(
        name="WSL User",
        description="Which Linux user to use inside the selected WSL distro",
        default=DEFAULT_WSL_USER,
    )
    repo_2mv_path: StringProperty(
        name="2mv Path",
        default=DEFAULT_REPO_2MV_PATH,
    )
    repo_21_path: StringProperty(
        name="2.1 Path",
        default=DEFAULT_REPO_21_PATH,
    )
    repo_n2d2_path: StringProperty(
        name="Nymphs2D2 Path",
        default=DEFAULT_REPO_N2D2_PATH,
    )
    n2d2_model_id: StringProperty(
        name="Model ID",
        description="Hugging Face model id for Nymphs2D2",
        default=DEFAULT_N2D2_MODEL_ID,
    )
    n2d2_model_variant: StringProperty(
        name="Model Variant",
        description="Optional model variant such as fp16",
        default=DEFAULT_N2D2_MODEL_VARIANT,
    )
    shape_workflow: EnumProperty(
        name="Shape Workflow",
        items=(
            ("IMAGE", "Image to 3D", "Generate shape from one image"),
            ("MULTIVIEW", "Multiview to 3D", "Generate shape from front/back/left/right images"),
            ("TEXT", "Text to 3D", "Generate shape from a text prompt"),
        ),
        default="IMAGE",
    )
    prompt: StringProperty(
        name="Prompt",
        description="Optional text prompt or text-only request",
        default="",
    )
    image_path: StringProperty(
        name="Image",
        description="Source image for image or retexture workflows",
        subtype="FILE_PATH",
        default="",
    )
    mv_front: StringProperty(name="Front", subtype="FILE_PATH", default="")
    mv_back: StringProperty(name="Back", subtype="FILE_PATH", default="")
    mv_left: StringProperty(name="Left", subtype="FILE_PATH", default="")
    mv_right: StringProperty(name="Right", subtype="FILE_PATH", default="")
    auto_remove_background: BoolProperty(
        name="Auto Remove Background",
        default=True,
    )
    mesh_detail: IntProperty(
        name="Mesh Detail",
        default=256,
        min=128,
        max=512,
    )
    detail_passes: IntProperty(
        name="Detail Passes",
        default=20,
        min=10,
        max=100,
    )
    reference_strength: FloatProperty(
        name="Reference Strength",
        default=5.5,
        min=1.0,
        max=12.0,
    )
    shape_generate_texture: BoolProperty(
        name="Also Generate Texture",
        default=True,
    )
    texture_face_limit: IntProperty(
        name="Face Limit",
        default=40000,
        min=1000,
        max=100000,
    )
    texture_max_views: IntProperty(
        name="Max Views",
        default=6,
        min=6,
        max=12,
    )
    texture_resolution: EnumProperty(
        name="Texture Size",
        items=(
            ("512", "512 px", "Lower VRAM and faster texture synthesis"),
            ("768", "768 px", "Higher quality but heavier texture synthesis"),
        ),
        default="512",
    )
    texture_resolution_2mv: EnumProperty(
        name="Texture Size",
        items=(
            ("512", "512 px", "Lowest VRAM and fastest 2mv texturing"),
            ("1024", "1024 px", "Lower VRAM and faster 2mv texturing"),
            ("2048", "2048 px", "Higher quality but heavier 2mv texturing"),
        ),
        default="2048",
    )
    texture_use_remesh: BoolProperty(
        name="Remesh Uploaded Mesh",
        description="Experimental. Rebuild the uploaded mesh before texturing. Can help some meshes but may damage others.",
        default=False,
    )
    show_startup: BoolProperty(default=True)
    show_texture_settings: BoolProperty(default=False)
    show_image_generation: BoolProperty(default=True)
    show_details: BoolProperty(default=False)
    show_gpu: BoolProperty(default=True)
    show_advanced: BoolProperty(default=False)
    show_shape: BoolProperty(default=True)
    show_texture: BoolProperty(default=True)
    imagegen_prompt: StringProperty(
        name="Prompt",
        description="Prompt sent to Nymphs2D2 for image generation",
        default="",
    )
    imagegen_negative_prompt: StringProperty(
        name="Negative Prompt",
        description="Optional negative prompt for image generation",
        default="",
    )
    imagegen_width: IntProperty(
        name="Width",
        default=1024,
        min=256,
        max=1536,
    )
    imagegen_height: IntProperty(
        name="Height",
        default=1024,
        min=256,
        max=1536,
    )
    imagegen_steps: IntProperty(
        name="Steps",
        default=9,
        min=1,
        max=100,
    )
    imagegen_guidance_scale: FloatProperty(
        name="Guidance",
        default=0.0,
        min=0.0,
        max=20.0,
    )
    imagegen_seed: StringProperty(
        name="Seed",
        description="Leave blank for a random seed",
        default="",
    )
    imagegen_started_at: FloatProperty(default=0.0)
    imagegen_is_busy: BoolProperty(default=False)
    imagegen_status_text: StringProperty(
        name="Image Generation Status",
        default="Idle",
    )
    imagegen_task_status: StringProperty(default="")
    imagegen_task_stage: StringProperty(default="")
    imagegen_task_detail: StringProperty(default="")
    imagegen_task_progress: StringProperty(default="")
    imagegen_output_path: StringProperty(
        name="Last Generated Image",
        default="",
    )
    imagegen_output_dir: StringProperty(
        name="Generated Image Folder",
        default="",
    )
    imagegen_metadata_path: StringProperty(
        name="Last Image Metadata",
        default="",
    )
    shape_output_path: StringProperty(
        name="Last Generated Mesh",
        default="",
    )
    shape_output_dir: StringProperty(
        name="Generated Mesh Folder",
        default="",
    )
    is_busy: BoolProperty(default=False)
    status_text: StringProperty(
        name="Status",
        default="Idle",
    )
    backend_summary: StringProperty(
        name="Backend Summary",
        default="Not checked",
    )
    gpu_summary: StringProperty(
        name="GPU Summary",
        default="Not checked",
    )
    gpu_name: StringProperty(name="GPU Name", default="Unknown")
    gpu_memory: StringProperty(name="GPU Memory", default="Unavailable")
    gpu_utilization: StringProperty(name="GPU Utilization", default="Unavailable")
    gpu_status_message: StringProperty(name="GPU Status", default="Not checked")
    launch_state: StringProperty(
        name="Launch State",
        default="Stopped",
    )
    launch_detail: StringProperty(
        name="Launch Detail",
        default="No local backend launched from Blender.",
    )
    backend_family: StringProperty(default="Unknown")
    server_supports_shape: BoolProperty(default=False)
    server_supports_texture: BoolProperty(default=False)
    server_supports_retexture: BoolProperty(default=False)
    server_supports_multiview: BoolProperty(default=False)
    server_supports_text: BoolProperty(default=False)
    server_texture_only: BoolProperty(default=False)
    task_status: StringProperty(default="idle")
    task_stage: StringProperty(default="")
    task_detail: StringProperty(default="")
    task_progress: StringProperty(default="")
    task_message: StringProperty(default="")
    waiting_for_backend_progress: BoolProperty(default=False)
    saw_real_backend_progress: BoolProperty(default=False)
    generation_request_finished_locally: BoolProperty(default=False)
    last_result: StringProperty(
        name="Last Result",
        default="",
    )


def _service_display_name(service_key):
    return SERVICE_LABELS[service_key]


def _backend_display_name(label):
    mapping = {
        "2mv": SERVICE_LABELS["2mv"],
        "2.0": SERVICE_LABELS["2mv"],
        "2.1": SERVICE_LABELS["21"],
        "Nymphs2D2": SERVICE_LABELS["n2d2"],
    }
    return mapping.get(label, label)


def _apply_service_state(state, service_key, **changes):
    for attr_name, value in _service_changes(service_key, **changes).items():
        setattr(state, attr_name, value)

    if service_key == _selected_3d_service_key(state):
        if "launch_state" in changes:
            state.launch_state = changes["launch_state"]
        if "launch_detail" in changes:
            state.launch_detail = changes["launch_detail"]


def _start_service_process(context, state, service_key):
    if _backend_is_alive(service_key):
        return False, f"{_service_display_name(service_key)} is already running."

    if service_key in {"2mv", "21"}:
        _sync_local_api(state)

    shell = _compose_wsl_launch(state, service_key)
    port = _service_port(state, service_key)

    try:
        _best_effort_stop_local(port, state, service_key=service_key)
        popen_kwargs = {
            "text": True,
            "bufsize": 1,
        }
        if os.name == "nt":
            if state.launch_open_terminal:
                popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
                popen_kwargs["stdout"] = None
                popen_kwargs["stderr"] = None
            else:
                popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                popen_kwargs["stdout"] = subprocess.PIPE
                popen_kwargs["stderr"] = subprocess.STDOUT
        else:
            popen_kwargs["stdout"] = subprocess.PIPE
            popen_kwargs["stderr"] = subprocess.STDOUT

        proc = subprocess.Popen(_compose_wsl_invocation(shell, state), **popen_kwargs)
    except Exception as exc:
        changes = {
            "launch_state": "Stopped",
            "launch_detail": str(exc),
            "backend_summary": "Unavailable",
        }
        if service_key in {"2mv", "21"}:
            changes.update(
                {
                    "backend_family": "Unknown",
                    "server_supports_shape": False,
                    "server_supports_texture": False,
                    "server_supports_retexture": False,
                    "server_supports_multiview": False,
                    "server_supports_text": False,
                    "server_texture_only": False,
                }
            )
        _apply_service_state(state, service_key, **changes)
        return False, f"Launch failed: {exc}"

    _remember_backend(
        service_key,
        proc,
        {
            "service_key": service_key,
            "port": port,
            "wsl_distro_name": _resolved_wsl_distro_name(state),
            "wsl_user_name": _resolved_wsl_user_name(state),
        },
    )
    _apply_service_state(
        state,
        service_key,
        launch_state="Launching",
        launch_detail=f"Starting {_service_display_name(service_key)}...",
        backend_summary="Waiting for /server_info...",
    )

    if proc.stdout is not None:
        threading.Thread(
            target=_backend_stdout_pump,
            args=(context.scene.name, proc, service_key),
            daemon=True,
        ).start()
    threading.Thread(
        target=_backend_lifecycle,
        args=(context.scene.name, proc, service_key),
        daemon=True,
    ).start()
    return True, f"{_service_display_name(service_key)} launch requested."


def _stop_service_process(state, service_key):
    proc = _managed_backend(service_key)
    if proc is None or proc.poll() is not None:
        _best_effort_stop_local(_service_port(state, service_key), state, service_key=service_key)
        changes = {
            "launch_state": "Stopped",
            "launch_detail": f"{_service_display_name(service_key)} is not running.",
            "backend_summary": "Unavailable",
        }
        if service_key in {"2mv", "21"}:
            changes.update(
                {
                    "backend_family": "Unknown",
                    "server_supports_shape": False,
                    "server_supports_texture": False,
                    "server_supports_retexture": False,
                    "server_supports_multiview": False,
                    "server_supports_text": False,
                    "server_texture_only": False,
                }
            )
        _apply_service_state(state, service_key, **changes)
        return False, f"{_service_display_name(service_key)} is not running."

    try:
        proc.terminate()
    except Exception as exc:
        return False, f"Stop failed: {exc}"

    _best_effort_stop_local(_service_port(state, service_key), state, service_key=service_key)
    _apply_service_state(
        state,
        service_key,
        launch_state="Stopping",
        launch_detail=f"Stopping {_service_display_name(service_key)}...",
    )
    return True, f"{_service_display_name(service_key)} stop requested."


class NYMPHSV2_OT_probe_backend(bpy.types.Operator):
    bl_idname = "nymphsv2.probe_backend"
    bl_label = "Refresh Backends"
    bl_description = "Fetch /server_info from the local managed backends"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        threading.Thread(target=_background_primary_probe, args=(context.scene.name,), daemon=True).start()
        for service_key in SERVICE_ORDER:
            if _service_enabled(state, service_key) or _backend_is_alive(service_key):
                threading.Thread(
                    target=_background_server_probe,
                    args=(context.scene.name, service_key),
                    daemon=True,
                ).start()
        state.status_text = "Backend refresh requested."
        _schedule_event_loop()
        return {"FINISHED"}


class NYMPHSV2_OT_probe_gpu(bpy.types.Operator):
    bl_idname = "nymphsv2.probe_gpu"
    bl_label = "Refresh GPU"
    bl_description = "Probe host GPU usage with nvidia-smi"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        stats = _probe_gpu_host()
        state.gpu_name = stats["name"]
        state.gpu_memory = stats["memory"]
        state.gpu_utilization = stats["utilization"]
        state.gpu_status_message = stats["status"]
        state.status_text = "GPU probe finished."
        return {"FINISHED"}


class NYMPHSV2_OT_start_backend(bpy.types.Operator):
    bl_idname = "nymphsv2.start_backend"
    bl_label = "Start Enabled"
    bl_description = "Launch the enabled local WSL backends from Blender"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        started = []
        skipped = []
        for service_key in SERVICE_ORDER:
            if not _service_enabled(state, service_key):
                continue
            ok, message = _start_service_process(context, state, service_key)
            if ok:
                started.append(_service_display_name(service_key))
            else:
                skipped.append(message)

        if not started and not skipped:
            state.status_text = "No services are enabled."
            return {"CANCELLED"}

        if started:
            state.status_text = f"Started: {', '.join(started)}"
        else:
            state.status_text = skipped[0]
        _schedule_event_loop()
        return {"FINISHED"}


class NYMPHSV2_OT_stop_backend(bpy.types.Operator):
    bl_idname = "nymphsv2.stop_backend"
    bl_label = "Stop All"
    bl_description = "Stop all managed local WSL backends"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        stopped_any = False
        for service_key in SERVICE_ORDER:
            ok, _message = _stop_service_process(state, service_key)
            stopped_any = stopped_any or ok
        if not stopped_any:
            _best_effort_stop_local(state=state)
            state.launch_state = "Stopped"
            state.launch_detail = "No managed backends were running."
            state.status_text = "No managed backends were running."
            return {"CANCELLED"}
        state.status_text = "Stop requested."
        _schedule_event_loop()
        return {"FINISHED"}


class NYMPHSV2_OT_start_service(bpy.types.Operator):
    bl_idname = "nymphsv2.start_service"
    bl_label = "Start Service"
    bl_description = "Launch one managed local WSL backend"

    service_key: StringProperty()

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        ok, message = _start_service_process(context, state, self.service_key)
        state.status_text = message
        _schedule_event_loop()
        return {"FINISHED"} if ok else {"CANCELLED"}


class NYMPHSV2_OT_stop_service(bpy.types.Operator):
    bl_idname = "nymphsv2.stop_service"
    bl_label = "Stop Service"
    bl_description = "Stop one managed local WSL backend"

    service_key: StringProperty()

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        ok, message = _stop_service_process(state, self.service_key)
        state.status_text = message
        _schedule_event_loop()
        return {"FINISHED"} if ok else {"CANCELLED"}


class NYMPHSV2_OT_set_3d_target(bpy.types.Operator):
    bl_idname = "nymphsv2.set_3d_target"
    bl_label = "Set 3D Target"
    bl_description = "Use this Hunyuan backend for 3D requests"

    service_key: StringProperty()

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        state.launch_backend = "BACKEND_21" if self.service_key == "21" else "BACKEND_2MV"
        _sync_local_api(state)
        state.status_text = f"3D target set to {_service_display_name(_selected_3d_service_key(state))}."
        _touch_ui()
        return {"FINISHED"}


def _submit_request(context, state, payload, source_name, status_text):
    api_root = _normalize_api_root(state.api_root)
    state.is_busy = True
    state.status_text = status_text
    state.last_result = ""
    state.generation_request_finished_locally = False
    state.task_status = "queued"
    state.task_stage = "Request Sent"
    state.task_detail = "Waiting for backend progress..."
    state.task_progress = ""
    state.task_message = ""
    state.waiting_for_backend_progress = True
    state.saw_real_backend_progress = False
    _touch_ui()

    worker = threading.Thread(
        target=_job_worker,
        args=(context.scene.name, api_root, payload, source_name),
        daemon=True,
    )
    worker.start()
    _schedule_event_loop()


class NYMPHSV2_OT_run_shape_request(bpy.types.Operator):
    bl_idname = "nymphsv2.run_shape_request"
    bl_label = "Generate Shape"
    bl_description = "Send the current shape request to the backend and import the result"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        if state.is_busy or state.imagegen_is_busy:
            self.report({"WARNING"}, "A request is already running.")
            return {"CANCELLED"}

        caps = _state_server_capabilities(state)
        texture_requested = bool(state.shape_generate_texture and caps["texture"])
        if not caps["shape"] or caps["texture_only"]:
            self.report({"ERROR"}, "The current server is not exposing shape generation.")
            return {"CANCELLED"}
        if state.shape_workflow == "MULTIVIEW" and not caps["multiview"]:
            self.report({"ERROR"}, "The current server does not support multiview shape generation.")
            return {"CANCELLED"}
        if state.shape_workflow == "TEXT" and not caps["text"]:
            self.report({"ERROR"}, "The current server was not started with text support.")
            return {"CANCELLED"}

        try:
            api_root = _normalize_api_root(state.api_root)
            _require_network_access(api_root)
            payload = _build_shape_payload(state)
            payload["texture"] = texture_requested
            if texture_requested:
                payload.update(_texture_option_payload(state))
        except Exception as exc:
            state.status_text = str(exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        if state.shape_workflow == "MULTIVIEW":
            status_text = "Submitting multiview shape request..."
            if texture_requested:
                status_text = "Submitting multiview shape + texture request..."
        elif state.shape_workflow == "TEXT":
            status_text = "Submitting text-to-3D request..."
            if texture_requested:
                status_text = "Submitting text-to-3D + texture request..."
        else:
            status_text = "Submitting image-to-3D request..."
            if texture_requested:
                status_text = "Submitting image-to-3D + texture request..."

        _submit_request(context, state, payload, "", status_text)
        return {"FINISHED"}


class NYMPHSV2_OT_run_texture_request(bpy.types.Operator):
    bl_idname = "nymphsv2.run_texture_request"
    bl_label = "Retexture Selected Mesh"
    bl_description = "Send the selected mesh to the backend texture path and import the result"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        if state.is_busy or state.imagegen_is_busy:
            self.report({"WARNING"}, "A request is already running.")
            return {"CANCELLED"}

        caps = _state_server_capabilities(state)
        if not caps["retexture"]:
            self.report({"ERROR"}, "The current server does not expose mesh retexturing.")
            return {"CANCELLED"}

        try:
            api_root = _normalize_api_root(state.api_root)
            _require_network_access(api_root)
            mesh_format = _preferred_texture_mesh_format(state, caps)
            mesh_b64, source_name = _export_selected_mesh_base64(context, export_format=mesh_format)
            payload = _build_texture_payload(state, mesh_b64=mesh_b64, mesh_format=mesh_format)
        except Exception as exc:
            state.status_text = str(exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        _submit_request(context, state, payload, source_name, "Texturing selected mesh...")
        return {"FINISHED"}


class NYMPHSV2_OT_generate_image(bpy.types.Operator):
    bl_idname = "nymphsv2.generate_image"
    bl_label = "Generate Image"
    bl_description = "Generate one image through the Nymphs2D2 backend and assign it to Image"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        if state.is_busy or state.imagegen_is_busy:
            self.report({"WARNING"}, "Another request is already running.")
            return {"CANCELLED"}

        api_root = _normalize_api_root(_service_api_root(state, "n2d2"))
        try:
            _require_network_access(api_root)
            payload = _build_imagegen_payload(state)
        except Exception as exc:
            state.imagegen_status_text = str(exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        state.imagegen_is_busy = True
        state.imagegen_started_at = time.time()
        state.imagegen_status_text = "Generating image..."
        state.imagegen_task_status = "queued"
        state.imagegen_task_stage = "Generating Image"
        state.imagegen_task_detail = "Waiting for image backend progress..."
        state.imagegen_task_progress = ""
        state.imagegen_output_path = ""
        state.imagegen_metadata_path = ""
        _touch_ui()

        worker = threading.Thread(
            target=_imagegen_worker,
            args=(context.scene.name, api_root, payload),
            daemon=True,
        )
        worker.start()
        _schedule_event_loop()
        return {"FINISHED"}


class NYMPHSV2_OT_edit_image_prompts(bpy.types.Operator):
    bl_idname = "nymphsv2.edit_image_prompts"
    bl_label = "Edit Image Prompts"
    bl_description = "Open a wider editor for the image prompt and negative prompt"

    prompt: StringProperty(
        name="Prompt",
        description="Prompt sent to Nymphs2D2 for image generation",
        default="",
    )
    negative_prompt: StringProperty(
        name="Negative Prompt",
        description="Optional negative prompt for image generation",
        default="",
    )

    def invoke(self, context, event):
        state = context.scene.nymphs3d2v2_state
        self.prompt = state.imagegen_prompt
        self.negative_prompt = state.imagegen_negative_prompt
        return context.window_manager.invoke_props_dialog(self, width=980)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        body = layout.column(align=True)
        body.label(text="Prompt")
        prompt_row = body.row()
        prompt_row.scale_y = 1.15
        prompt_row.prop(self, "prompt", text="")
        _draw_wrapped_preview(body, "Prompt Preview", self.prompt, width=78, max_lines=8)
        body.separator()
        body.label(text="Negative Prompt")
        negative_row = body.row()
        negative_row.scale_y = 1.15
        negative_row.prop(self, "negative_prompt", text="")
        _draw_wrapped_preview(body, "Negative Preview", self.negative_prompt, width=78, max_lines=6)

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        state.imagegen_prompt = self.prompt
        state.imagegen_negative_prompt = self.negative_prompt
        _touch_ui()
        return {"FINISHED"}


class NYMPHSV2_OT_open_imagegen_folder(bpy.types.Operator):
    bl_idname = "nymphsv2.open_imagegen_folder"
    bl_label = "Open Folder"
    bl_description = "Open the folder that contains the generated Nymphs2D2 images"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        folder_path = (state.imagegen_output_dir or "").strip()
        if not folder_path and state.imagegen_output_path.strip():
            folder_path = os.path.dirname(state.imagegen_output_path.strip())
        if not folder_path:
            self.report({"ERROR"}, "No generated image folder is available yet.")
            return {"CANCELLED"}
        try:
            bpy.ops.wm.path_open(filepath=folder_path)
        except Exception as exc:
            self.report({"ERROR"}, f"Could not open folder: {exc}")
            return {"CANCELLED"}
        return {"FINISHED"}


class NYMPHSV2_OT_clear_imagegen_folder(bpy.types.Operator):
    bl_idname = "nymphsv2.clear_imagegen_folder"
    bl_label = "Clear Folder"
    bl_description = "Delete generated image files from the current image output folder"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        folder_path = (state.imagegen_output_dir or "").strip()
        if not folder_path and state.imagegen_output_path.strip():
            folder_path = os.path.dirname(state.imagegen_output_path.strip())
        try:
            _clear_folder_contents(folder_path)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        state.imagegen_output_path = ""
        state.imagegen_metadata_path = ""
        state.imagegen_status_text = "Image output folder cleared."
        _touch_ui()
        return {"FINISHED"}


class NYMPHSV2_OT_open_shape_folder(bpy.types.Operator):
    bl_idname = "nymphsv2.open_shape_folder"
    bl_label = "Open Folder"
    bl_description = "Open the folder that contains the latest generated mesh"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        folder_path = (state.shape_output_dir or "").strip()
        if not folder_path and state.shape_output_path.strip():
            folder_path = os.path.dirname(state.shape_output_path.strip())
        if not folder_path:
            self.report({"ERROR"}, "No generated mesh folder is available yet.")
            return {"CANCELLED"}
        try:
            bpy.ops.wm.path_open(filepath=folder_path)
        except Exception as exc:
            self.report({"ERROR"}, f"Could not open folder: {exc}")
            return {"CANCELLED"}
        return {"FINISHED"}


class NYMPHSV2_OT_clear_shape_folder(bpy.types.Operator):
    bl_idname = "nymphsv2.clear_shape_folder"
    bl_label = "Clear Folder"
    bl_description = "Delete generated mesh files from the current shape output folder"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        folder_path = (state.shape_output_dir or "").strip()
        if not folder_path and state.shape_output_path.strip():
            folder_path = os.path.dirname(state.shape_output_path.strip())
        try:
            _clear_folder_contents(folder_path)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        state.shape_output_path = ""
        state.last_result = "Shape output folder cleared."
        _touch_ui()
        return {"FINISHED"}


class NYMPHSV2_PT_server(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Nymphs"
    bl_label = "Nymphs Server"

    def draw(self, context):
        state = context.scene.nymphs3d2v2_state
        layout = self.layout

        top = layout.box()
        progress_stage, progress_detail, progress_value = _server_panel_job_lines(state)
        current_job = progress_stage or "Idle"
        current_detail = progress_detail or state.launch_detail
        active_services = _active_service_summaries(state)
        gpu_summary = ""
        if (state.gpu_utilization or "").strip() or (state.gpu_memory or "").strip():
            gpu_parts = []
            if (state.gpu_utilization or "").strip():
                gpu_parts.append(f"Load {state.gpu_utilization}")
            if (state.gpu_memory or "").strip():
                gpu_parts.append(f"VRAM {state.gpu_memory}")
            gpu_summary = " | ".join(gpu_parts)
        if current_detail and progress_value and current_detail.strip() == progress_value.strip():
            current_detail = ""
        top.label(text=f"Status: {_server_status_line(state)}"[:160])
        if active_services:
            top.label(text=f"Runtimes: {' | '.join(active_services)}"[:160])
        if gpu_summary:
            top.label(text=f"GPU: {gpu_summary}"[:160])
        top.label(text=f"Current Job: {current_job}"[:160])
        if current_detail:
            top.label(text=f"Detail: {_scroll_text(current_detail)}"[:160])
        if progress_value:
            top.label(text=f"Progress: {progress_value}"[:160])

        startup = layout.box()
        startup.prop(
            state,
            "show_startup",
            text="Runtimes",
            icon="TRIA_DOWN" if state.show_startup else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_startup:
            actions = startup.row(align=True)
            actions.operator("nymphsv2.start_backend", text="Start Enabled")
            actions.operator("nymphsv2.stop_backend", text="Stop All")
            actions.operator("nymphsv2.probe_backend", text="Refresh")
            _draw_service_block(startup, state, "2mv")
            _draw_service_block(startup, state, "n2d2")
            _draw_service_block(startup, state, "21")

        advanced = layout.box()
        advanced.prop(
            state,
            "show_advanced",
            text="Advanced",
            icon="TRIA_DOWN" if state.show_advanced else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_advanced:
            target = advanced.box()
            target.label(text="WSL Target")
            target.use_property_split = True
            target.use_property_decorate = False
            target.prop(state, "wsl_distro_name", text="Distro")
            target.prop(state, "wsl_user_name", text="User")
            advanced.prop(state, "launch_open_terminal")
            advanced.prop(state, "api_root")
            advanced.label(text=f"Selected 3D API: {_service_api_root(state, _selected_3d_service_key(state))}"[:160])

        info = layout.box()
        info.prop(
            state,
            "show_details",
            text="Details",
            icon="TRIA_DOWN" if state.show_details else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_details:
            info.label(text=f"Managed: {'Yes' if _backend_is_alive() else 'No'}")
            info.label(text=f"Launch State: {state.launch_state}")
            info.label(text=f"Backend: {state.backend_summary}"[:160])
            info.label(text=f"Task Status: {state.task_status}"[:160])
            info.label(text=f"Task Stage: {state.task_stage}"[:160])
            if state.task_detail:
                info.label(text=f"Task Detail: {state.task_detail}"[:160])
            if state.task_progress:
                info.label(text=f"Task Progress: {state.task_progress}"[:160])
            estimate, basis, mode, caveat = _current_vram_estimate(state)
            info.separator()
            info.label(text=f"VRAM Estimate: {estimate}"[:160])
            info.label(text=f"VRAM Mode: {mode}"[:160])
            info.label(text=basis[:160])
            info.label(text=f"Caveat: {caveat}"[:160])

        gpu = layout.box()
        gpu.prop(
            state,
            "show_gpu",
            text="GPU",
            icon="TRIA_DOWN" if state.show_gpu else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_gpu:
            gpu.operator("nymphsv2.probe_gpu", text="Refresh GPU")
            gpu.label(text=f"GPU: {state.gpu_name}"[:160])
            gpu.label(text=f"VRAM: {state.gpu_memory}"[:160])
            gpu.label(text=f"Load: {state.gpu_utilization}"[:160])
            gpu.label(text=f"Driver Status: {state.gpu_status_message}"[:160])


class NYMPHSV2_PT_image_generation(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Nymphs"
    bl_label = "Nymphs Image"

    def draw(self, context):
        state = context.scene.nymphs3d2v2_state
        layout = self.layout

        panel = layout.box()
        panel.prop(
            state,
            "show_image_generation",
            text="Image Generation",
            icon="TRIA_DOWN" if state.show_image_generation else "TRIA_RIGHT",
            emboss=False,
        )
        if not state.show_image_generation:
            return

        service = panel.box()
        service.label(text=f"Service: {_service_status_line(state, 'n2d2')}")
        summary = (_service_get(state, "n2d2", "backend_summary", "Unavailable") or "").strip()
        if summary:
            service.label(text=f"Backend: {summary}"[:160])
        if not _backend_is_alive("n2d2") and summary in {"Unavailable", "Not checked", ""}:
            service.label(text="Start Nymphs2D in the Server panel.")

        request = panel.box()
        edit_row = request.row(align=True)
        edit_row.operator("nymphsv2.edit_image_prompts", text="Edit Prompt Text")
        request.label(text="Prompt")
        _draw_wrapped_preview(request, "Current", state.imagegen_prompt, width=42, max_lines=5)
        request.label(text="Negative Prompt")
        _draw_wrapped_preview(request, "Current", state.imagegen_negative_prompt, width=42, max_lines=4)
        size_row = request.row(align=True)
        size_row.prop(state, "imagegen_width")
        size_row.prop(state, "imagegen_height")
        settings_row = request.row(align=True)
        settings_row.prop(state, "imagegen_steps")
        settings_row.prop(state, "imagegen_guidance_scale")
        request.prop(state, "imagegen_seed")

        action = panel.row()
        action.enabled = not state.is_busy and not state.imagegen_is_busy
        action.operator("nymphsv2.generate_image", text="Generate Image")

        result = panel.box()
        result.label(text=f"Status: {state.imagegen_status_text}"[:160])
        if state.imagegen_output_path:
            if state.imagegen_output_dir:
                result.label(text=f"Folder: {_scroll_text(state.imagegen_output_dir, window=36)}"[:160])
            result.label(text=f"Last Image: {_scroll_text(state.imagegen_output_path, window=36)}"[:160])
            action_row = result.row(align=True)
            action_row.operator("nymphsv2.open_imagegen_folder", text="Open Folder")
            action_row.operator("nymphsv2.clear_imagegen_folder", text="Clear Folder")
            result.label(text="Assigned to the main Image field.")


def _panel_status_text(state):
    if state.last_result:
        return state.last_result
    active_status = (state.task_status or "").lower()
    if state.is_busy or active_status in {"processing", "queued"}:
        if state.waiting_for_backend_progress or active_status == "queued":
            return "Submitting..."
        return "Running..."

    status_text = (state.status_text or "").strip()
    if not status_text:
        return "Ready"

    lowered = status_text.lower()
    passive_prefixes = (
        "submitting ",
        "launch ",
        "stop ",
        "backend probe",
        "gpu probe",
        "generation finished",
        "mesh imported",
        "local backend is ready",
    )
    passive_exact = {
        "Launch requested.",
        "Stop requested.",
        "Backend probe succeeded.",
        "GPU probe finished.",
        "Local backend is ready.",
        "No managed backend was running.",
        "A managed backend is already running.",
    }
    if status_text in passive_exact or lowered.startswith(passive_prefixes):
        return "Ready"

    return status_text


def _wrap_panel_text(text, width=44, max_lines=4):
    if not text:
        return []
    wrapped_lines = []
    for raw_line in text.strip().splitlines() or [""]:
        line_chunks = textwrap.wrap(
            raw_line,
            width=width,
            break_long_words=False,
            break_on_hyphens=False,
        )
        wrapped_lines.extend(line_chunks or [""])
    if len(wrapped_lines) > max_lines:
        wrapped_lines = wrapped_lines[:max_lines]
        if wrapped_lines:
            last = wrapped_lines[-1]
            max_last = max(1, width - 3)
            wrapped_lines[-1] = (last[:max_last] + "...") if len(last) > max_last else (last + "...")
    return wrapped_lines


def _draw_wrapped_preview(layout, title, text, width=44, max_lines=4):
    if not (text or "").strip():
        return
    preview = layout.box()
    preview.label(text=title)
    for line in _wrap_panel_text(text, width=width, max_lines=max_lines):
        preview.label(text=line)


def _draw_request_status(panel, state):
    status = panel.box()
    status.label(text=f"Status: {_panel_status_text(state)}"[:160])
    if state.task_stage:
        stage_norm = _normalized_panel_text(state.task_stage)
        if stage_norm and stage_norm not in {"idle", "request sent"}:
            status.label(text=f"Current Job: {state.task_stage}"[:160])
    if state.last_result:
        status.label(text=state.last_result[:160])


def _service_status_line(state, service_key):
    launch_state = _service_get(state, service_key, "launch_state", "Stopped")
    summary = (_service_get(state, service_key, "backend_summary", "Unavailable") or "").strip()
    if launch_state == "Launching":
        return "Launching"
    if launch_state == "Stopping":
        return "Stopping"
    if summary and summary not in {"Unavailable", "Not checked", ""}:
        return "Ready"
    if _backend_is_alive(service_key):
        return "Running"
    return "Stopped"


def _draw_service_block(layout, state, service_key):
    label = _service_display_name(service_key)
    show_attr = _service_prop_name(service_key, "show")
    enabled_attr = _service_prop_name(service_key, "enabled")
    port_attr = _service_prop_name(service_key, "port")
    detail = _service_get(state, service_key, "launch_detail", "")
    summary = _service_get(state, service_key, "backend_summary", "Unavailable")
    box = layout.box()

    header = box.row(align=True)
    header.prop(state, enabled_attr, text="")
    header.prop(
        state,
        show_attr,
        text="",
        icon="TRIA_DOWN" if getattr(state, show_attr) else "TRIA_RIGHT",
        emboss=False,
    )
    header.label(text=label)

    actions = box.row(align=True)
    actions.label(text=f"{_service_status_line(state, service_key)}  |  :{_service_port(state, service_key)}")
    start_op = actions.operator("nymphsv2.start_service", text="Start")
    start_op.service_key = service_key
    stop_op = actions.operator("nymphsv2.stop_service", text="Stop")
    stop_op.service_key = service_key

    if not getattr(state, show_attr):
        return

    details = box.column(align=True)
    details.prop(state, port_attr)
    details.label(text=f"Summary: {summary}"[:160])
    if detail:
        details.label(text=f"Detail: {_scroll_text(detail)}"[:160])
    if service_key in {"2mv", "21"}:
        target_row = details.row(align=True)
        if service_key == _selected_3d_service_key(state):
            target_row.label(text="Current 3D Target")
        else:
            target_op = target_row.operator("nymphsv2.set_3d_target", text="Use For 3D")
            target_op.service_key = service_key

    if service_key == "2mv":
        details.prop(state, "repo_2mv_path")
        row = details.row(align=True)
        row.prop(state, "launch_texture_support")
        row.prop(state, "launch_text_bridge")
        row = details.row(align=True)
        row.prop(state, "launch_turbo")
        row.prop(state, "launch_flashvdm")
    elif service_key == "21":
        details.prop(state, "repo_21_path")
        row = details.row(align=True)
        tex_row = row.row(align=True)
        tex_row.enabled = not state.launch_texture_only
        tex_row.prop(state, "launch_texture_support")
        row.prop(state, "launch_texture_only")
        row = details.row(align=True)
        text_row = row.row(align=True)
        text_row.enabled = not state.launch_texture_only
        text_row.prop(state, "launch_text_bridge")
        row.prop(state, "launch_low_vram")
    else:
        details.prop(state, "repo_n2d2_path")
        details.prop(state, "n2d2_model_id")
        details.prop(state, "n2d2_model_variant")
        details.label(text="Image-generation only in this branch.")


class NYMPHSV2_PT_shape(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Nymphs"
    bl_label = "Nymphs Shape"

    def draw(self, context):
        state = context.scene.nymphs3d2v2_state
        layout = self.layout
        caps = _state_server_capabilities(state)
        texture_requested = bool(state.shape_generate_texture and caps["texture"])

        panel = layout.box()
        panel.prop(
            state,
            "show_shape",
            text="Shape Request",
            icon="TRIA_DOWN" if state.show_shape else "TRIA_RIGHT",
            emboss=False,
        )
        if not state.show_shape:
            return

        if state.backend_summary == "Unavailable" and not _backend_is_alive():
            warn = panel.box()
            warn.label(text="Server info is unavailable.")
            warn.label(text="Start the local server above.")

        if not caps["shape"] or caps["texture_only"]:
            warn = panel.box()
            warn.label(text="Current server is not exposing shape generation.")
            warn.label(text="Use a shape-capable backend instance.")
            panel.label(text=f"Status: {_panel_status_text(state)}"[:160])
            return

        request = panel.box()
        request.label(text="Workflow")
        request.prop(state, "shape_workflow")

        text_row = request.row()
        text_row.enabled = caps["text"] or state.shape_workflow != "TEXT"
        text_row.prop(state, "prompt")
        if state.shape_workflow == "TEXT" and not caps["text"]:
            request.label(text="This server was not started with text support.")

        if state.shape_workflow == "IMAGE":
            request.prop(state, "image_path")
        elif state.shape_workflow == "MULTIVIEW":
            if not caps["multiview"]:
                request.label(text="Current server does not expose multiview.")
            request.prop(state, "mv_front")
            request.prop(state, "mv_back")
            request.prop(state, "mv_left")
            request.prop(state, "mv_right")

        request.prop(state, "auto_remove_background")
        texture_row = request.row()
        texture_row.enabled = caps["texture"]
        texture_row.prop(state, "shape_generate_texture")
        if not caps["texture"]:
            request.label(text="This server was started without texture support.")
            if state.shape_generate_texture:
                request.label(text="Shape requests will run without texture on this server.")
        request.prop(state, "mesh_detail")
        request.prop(state, "detail_passes")
        request.prop(state, "reference_strength")

        action = panel.row()
        workflow_supported = True
        if state.shape_workflow == "MULTIVIEW" and not caps["multiview"]:
            workflow_supported = False
        if state.shape_workflow == "TEXT" and not caps["text"]:
            workflow_supported = False
        action.enabled = not state.is_busy and not state.imagegen_is_busy and workflow_supported
        action.operator(
            "nymphsv2.run_shape_request",
            text="Generate Shape + Texture" if texture_requested else "Generate Shape",
        )

        if state.shape_output_path:
            result = panel.box()
            if state.shape_output_dir:
                result.label(text=f"Folder: {_scroll_text(state.shape_output_dir, window=36)}"[:160])
            result.label(text=f"Last Mesh: {_scroll_text(state.shape_output_path, window=36)}"[:160])
            action_row = result.row(align=True)
            action_row.operator("nymphsv2.open_shape_folder", text="Open Folder")
            action_row.operator("nymphsv2.clear_shape_folder", text="Clear Folder")

        _draw_request_status(panel, state)


class NYMPHSV2_PT_texture(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Nymphs"
    bl_label = "Nymphs Texture"

    def draw(self, context):
        state = context.scene.nymphs3d2v2_state
        layout = self.layout
        caps = _state_server_capabilities(state)

        panel = layout.box()
        panel.prop(
            state,
            "show_texture",
            text="Texture Request",
            icon="TRIA_DOWN" if state.show_texture else "TRIA_RIGHT",
            emboss=False,
        )
        if not state.show_texture:
            return

        info = panel.box()
        info.label(text="Retexture Selected Mesh")
        if not caps["texture"]:
            info.label(text="Current server does not expose texture generation.")
        elif not caps["retexture"]:
            info.label(text="Current server can texture generated shapes only.")
            info.label(text="Mesh retexturing is not exposed here yet.")
        elif caps["texture_only"]:
            info.label(text="Texture-only server mode is active.")

        request = panel.box()
        request.label(text="Texture Guidance")
        request.prop(state, "image_path")
        request.prop(state, "prompt")
        request.prop(state, "auto_remove_background")

        texture_opts = panel.box()
        texture_opts.prop(
            state,
            "show_texture_settings",
            text="Texture Options",
            icon="TRIA_DOWN" if state.show_texture_settings else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_texture_settings:
            texture_opts.prop(state, "texture_face_limit")
            active_family = caps["family"]
            if active_family == "Unknown":
                active_family = _launch_backend_label(state)

            if active_family == "2.1":
                texture_opts.prop(state, "texture_max_views")
                size_col = texture_opts.column(align=True)
                size_col.label(text="Texture Size")
                size_col.prop(state, "texture_resolution", text="")
                texture_opts.prop(state, "texture_use_remesh")
                texture_opts.label(text="2.1 options: Face Limit, Max Views, Texture Size, Remesh")
                if not state.texture_use_remesh:
                    texture_opts.label(text="Face Limit only applies when remesh is active.")
            else:
                texture_opts.label(text="2mv texture options: Face Limit, Texture Size")
                size_col = texture_opts.column(align=True)
                size_col.label(text="Texture Size")
                size_col.prop(state, "texture_resolution_2mv", text="")
                texture_opts.label(text="2mv speed/quality also lives in Startup: Texture, Turbo, FlashVDM")
                disabled = texture_opts.column(align=True)
                disabled.enabled = False
                disabled.prop(state, "texture_max_views")
                disabled.prop(state, "texture_use_remesh")
                texture_opts.label(text="The greyed controls above are 2.1-only.")

        action = panel.row()
        action.enabled = not state.is_busy and not state.imagegen_is_busy and caps["retexture"]
        action.operator("nymphsv2.run_texture_request", text="Retexture Selected Mesh")

        _draw_request_status(panel, state)


CLASSES = (
    NymphsV2State,
    NYMPHSV2_OT_probe_backend,
    NYMPHSV2_OT_probe_gpu,
    NYMPHSV2_OT_start_backend,
    NYMPHSV2_OT_stop_backend,
    NYMPHSV2_OT_start_service,
    NYMPHSV2_OT_stop_service,
    NYMPHSV2_OT_set_3d_target,
    NYMPHSV2_OT_run_shape_request,
    NYMPHSV2_OT_run_texture_request,
    NYMPHSV2_OT_generate_image,
    NYMPHSV2_OT_edit_image_prompts,
    NYMPHSV2_OT_open_imagegen_folder,
    NYMPHSV2_OT_clear_imagegen_folder,
    NYMPHSV2_OT_open_shape_folder,
    NYMPHSV2_OT_clear_shape_folder,
    NYMPHSV2_PT_server,
    NYMPHSV2_PT_image_generation,
    NYMPHSV2_PT_shape,
    NYMPHSV2_PT_texture,
)


def register():
    global ATEXIT_REGISTERED
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.nymphs3d2v2_state = PointerProperty(type=NymphsV2State)
    if not bpy.app.timers.is_registered(_server_probe_timer):
        bpy.app.timers.register(_server_probe_timer, persistent=True)
    if not bpy.app.timers.is_registered(_active_probe_timer):
        bpy.app.timers.register(_active_probe_timer, persistent=True)
    if not bpy.app.timers.is_registered(_gpu_probe_timer):
        bpy.app.timers.register(_gpu_probe_timer, persistent=True)
    if not ATEXIT_REGISTERED:
        atexit.register(_shutdown_managed_backends)
        ATEXIT_REGISTERED = True


def unregister():
    global ATEXIT_REGISTERED
    _shutdown_managed_backends()
    if bpy.app.timers.is_registered(_drain_events):
        bpy.app.timers.unregister(_drain_events)
    if bpy.app.timers.is_registered(_server_probe_timer):
        bpy.app.timers.unregister(_server_probe_timer)
    if bpy.app.timers.is_registered(_active_probe_timer):
        bpy.app.timers.unregister(_active_probe_timer)
    if bpy.app.timers.is_registered(_gpu_probe_timer):
        bpy.app.timers.unregister(_gpu_probe_timer)
    if ATEXIT_REGISTERED:
        try:
            atexit.unregister(_shutdown_managed_backends)
        except Exception:
            pass
        ATEXIT_REGISTERED = False
    del bpy.types.Scene.nymphs3d2v2_state
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

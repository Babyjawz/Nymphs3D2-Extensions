"""
Live Blender addon implementation for Nymphs3D2.
"""

bl_info = {
    "name": "Nymphs3D2",
    "author": "Nymphs3D",
    "version": (1, 0, 10),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Nymphs3D",
    "description": "Blender client for local or remote Nymphs3D backends",
    "category": "3D View",
}

import base64
import atexit
import json
import os
import queue
import re
import shlex
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)


LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}
EVENT_QUEUE = queue.Queue()
PROCESS_LOCK = threading.Lock()
MANAGED_BACKEND = None
MANAGED_BACKEND_TARGET = None
ATEXIT_REGISTERED = False
STAGE_LINE = re.compile(r"STAGE:\s*([A-Za-z0-9_]+)")
PROGRESS_LINE = re.compile(r"PROGRESS:\s*([A-Za-z0-9_ -]+)\s+(\d+)/(\d+)")
GPU_REFRESH_SECONDS = 2.0
SERVER_POLL_SECONDS = 6.0
SERVER_POLL_FAST_SECONDS = 2.0
ACTIVE_POLL_IDLE_SECONDS = 8.0
ACTIVE_POLL_BUSY_SECONDS = 1.5
ACTIVE_POLL_UNAVAILABLE_SECONDS = 15.0
ACTIVE_POLL_DIRECT_JOB_SECONDS = 0.75
LOG_PREFIX_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[^\|]*\|\s*[A-Z]+\s*\|\s*(?:stdout|stderr|[^|]+)\s*\|\s*")

DEFAULT_WSL_DISTRO = "Nymphs3D2"
DEFAULT_WSL_USER = "nymphs3d"
DEFAULT_REPO_2MV_PATH = "~/Hunyuan3D-2"
DEFAULT_REPO_21_PATH = "~/Hunyuan3D-2.1"
WSL_DISTRO_ITEMS = []


@dataclass
class ImportEvent:
    scene_name: str
    mesh_path: str
    source_object_name: str = ""


def _active_state(scene_name):
    scene = bpy.data.scenes.get(scene_name)
    if scene is None:
        return None
    return getattr(scene, "nymphs3d2v2_state", None)


def _touch_ui():
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return
    for window in wm.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _sync_shape_texture_state(state):
    if state is None:
        return
    if not bool(getattr(state, "server_supports_texture", False)):
        state.shape_generate_texture = False


def _schedule_event_loop():
    if not bpy.app.timers.is_registered(_drain_events):
        bpy.app.timers.register(_drain_events, first_interval=0.0)


def _emit_status(scene_name, **changes):
    EVENT_QUEUE.put(("status", scene_name, changes))
    _schedule_event_loop()


def _emit_import(scene_name, mesh_path, source_object_name=""):
    EVENT_QUEUE.put(("import", ImportEvent(scene_name, mesh_path, source_object_name), None))
    _schedule_event_loop()


def _drain_events():
    processed = False
    while True:
        try:
            kind, payload_a, payload_b = EVENT_QUEUE.get_nowait()
        except queue.Empty:
            break

        processed = True
        if kind == "status":
            state = _active_state(payload_a)
            if state is not None:
                for key, value in payload_b.items():
                    setattr(state, key, value)
                _sync_shape_texture_state(state)
        elif kind == "import":
            _import_result(payload_a)

    if processed:
        _touch_ui()

    if not EVENT_QUEUE.empty():
        return 0.1

    for scene in bpy.data.scenes:
        state = getattr(scene, "nymphs3d2v2_state", None)
        if state is not None and (
            state.is_busy or state.launch_state in {"Launching", "Stopping"}
        ):
            return 0.2

    return None


def _normalize_api_root(raw_value):
    value = (raw_value or "").strip()
    if not value:
        raise RuntimeError("API URL is required.")
    return value.rstrip("/")


def _online_access_enabled():
    value = getattr(bpy.app, "online_access", None)
    if value is not None:
        return bool(value)
    return True


def _require_network_access(api_root):
    parsed = urlparse(api_root)
    hostname = (parsed.hostname or "").strip().lower()
    if hostname and hostname not in LOCAL_HOSTS and not _online_access_enabled():
        raise RuntimeError("Enable Blender online access before using a remote API URL.")


def _http_call(method, url, payload=None, timeout=10):
    body = None
    headers = {}
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    request = Request(url=url, data=body, headers=headers, method=method)
    try:
        with urlopen(request, timeout=timeout) as response:
            return response.status, response.headers.get("Content-Type", ""), response.read()
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"HTTP {exc.code}: {detail or exc.reason}") from exc
    except URLError as exc:
        raise RuntimeError(f"Network error: {exc.reason}") from exc


def _json_call(method, url, payload=None, timeout=10):
    _, _, body = _http_call(method, url, payload=payload, timeout=timeout)
    try:
        return json.loads(body.decode("utf-8"))
    except Exception as exc:
        raise RuntimeError("Server returned invalid JSON.") from exc


def _format_progress_text(current=None, total=None, percent=None):
    if current is not None and total:
        return f"{current}/{total}"
    if percent is not None:
        try:
            return f"{float(percent):.0f}%"
        except Exception:
            return str(percent)
    return ""


def _stage_label(stage):
    labels = {
        "startup": "Starting server",
        "request_received": "Request Received",
        "loading_input_image": "Loading Input",
        "loading_input_mesh": "Loading Mesh",
        "normalizing_mesh": "Normalizing Mesh",
        "loading_shape_pipeline": "Loading Shape",
        "sampling_shape": "Generating Shape",
        "shape_ready": "Shape Ready",
        "loading_texture_pipeline": "Loading Texture",
        "generating_texture": "Generating Texture",
        "texture": "Generating Texture",
        "texture_ready": "Texture Ready",
        "exporting_mesh": "Exporting Mesh",
        "exporting_textured_mesh": "Exporting Textured Mesh",
        "failed": "Failed",
    }
    if not stage:
        return ""
    return labels.get(stage, stage.replace("_", " ").title())


def _launch_21_shape_enabled(state):
    return not bool(getattr(state, "launch_texture_only", False))


def _launch_21_texture_enabled(state):
    if bool(getattr(state, "launch_texture_only", False)):
        return True
    return bool(getattr(state, "launch_texture_support", True))


def _launch_21_texture_only(state):
    return bool(getattr(state, "launch_texture_only", False))


def _on_launch_texture_only_changed(self, context):
    if bool(getattr(self, "launch_texture_only", False)):
        # Texture-only mode is always a texture-capable 2.1 launch.
        self.launch_texture_support = True


def _resolve_file_path(raw_path):
    path = (raw_path or "").strip()
    if not path:
        return ""

    if path.startswith("//"):
        blend_dir = os.path.dirname(bpy.data.filepath)
        if blend_dir:
            path = os.path.join(blend_dir, path[2:])

    return bpy.path.abspath(path)


def _file_to_base64(raw_path):
    path = _resolve_file_path(raw_path)
    if not path or not os.path.exists(path):
        raise RuntimeError(f"Missing file: {raw_path}")
    with open(path, "rb") as handle:
        return base64.b64encode(handle.read()).decode("utf-8")


def _export_selected_mesh_base64(context, export_format="glb"):
    selected_meshes = [obj for obj in context.selected_objects if obj.type == "MESH"]
    if not selected_meshes:
        raise RuntimeError("Select a mesh object first.")

    active_object = context.active_object
    source_object = active_object if active_object in selected_meshes else selected_meshes[0]
    export_format = (export_format or "glb").strip().lower()
    if export_format not in {"glb", "obj"}:
        raise RuntimeError(f"Unsupported mesh export format: {export_format}")
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=f".{export_format}")
    temp_file.close()
    temp_mtl = os.path.splitext(temp_file.name)[0] + ".mtl"
    view_layer = context.view_layer
    previous_active = view_layer.objects.active
    previous_selection = list(context.selected_objects)
    try:
        bpy.ops.object.select_all(action="DESELECT")
        source_object.select_set(True)
        view_layer.objects.active = source_object
        if export_format == "obj":
            if hasattr(bpy.ops.wm, "obj_export"):
                bpy.ops.wm.obj_export(
                    filepath=temp_file.name,
                    export_selected_objects=True,
                    export_materials=False,
                )
            elif hasattr(bpy.ops.export_scene, "obj"):
                bpy.ops.export_scene.obj(
                    filepath=temp_file.name,
                    use_selection=True,
                    use_materials=False,
                )
            else:
                raise RuntimeError("OBJ export is not available in this Blender build.")
        else:
            bpy.ops.export_scene.gltf(filepath=temp_file.name, use_selection=True)
        with open(temp_file.name, "rb") as handle:
            return base64.b64encode(handle.read()).decode("utf-8"), source_object.name
    finally:
        bpy.ops.object.select_all(action="DESELECT")
        for obj in previous_selection:
            if obj and obj.name in bpy.data.objects:
                obj.select_set(True)
        if previous_active and previous_active.name in bpy.data.objects:
            view_layer.objects.active = previous_active
        if os.path.exists(temp_file.name):
            os.unlink(temp_file.name)
        if os.path.exists(temp_mtl):
            os.unlink(temp_mtl)


def _build_shape_payload(state):
    payload = {
        "octree_resolution": state.mesh_detail,
        "num_inference_steps": state.detail_passes,
        "guidance_scale": state.reference_strength,
        "remove_background": state.auto_remove_background,
        "texture": state.shape_generate_texture,
    }

    if state.shape_workflow == "TEXT":
        prompt = state.prompt.strip()
        if not prompt:
            raise RuntimeError("Enter a text prompt first.")
        payload["text"] = prompt
        return payload

    if state.shape_workflow == "IMAGE":
        payload["image"] = _file_to_base64(state.image_path)
        if state.prompt.strip():
            payload["text"] = state.prompt.strip()
        return payload

    if state.shape_workflow == "MULTIVIEW":
        views = {
            "mv_image_front": state.mv_front,
            "mv_image_back": state.mv_back,
            "mv_image_left": state.mv_left,
            "mv_image_right": state.mv_right,
        }
        encoded = {}
        for key, raw_path in views.items():
            if raw_path.strip():
                encoded[key] = _file_to_base64(raw_path)
        if "mv_image_front" not in encoded:
            raise RuntimeError("A front image is required for multiview mode.")
        payload.update(encoded)
        if state.prompt.strip():
            payload["text"] = state.prompt.strip()
        return payload

    raise RuntimeError(f"Unsupported shape workflow: {state.shape_workflow}")


def _build_texture_payload(state, mesh_b64, mesh_format="glb"):
    if not mesh_b64:
        raise RuntimeError("Selected mesh export failed.")

    payload = {
        "mesh": mesh_b64,
        "mesh_format": mesh_format,
        "texture": True,
        "remove_background": state.auto_remove_background,
    }
    payload.update(_texture_option_payload(state, include_use_remesh=True))

    if state.image_path.strip():
        payload["image"] = _file_to_base64(state.image_path)
    elif state.prompt.strip():
        payload["text"] = state.prompt.strip()
    else:
        raise RuntimeError("Texture mode needs either an image or a text prompt.")

    return payload


def _texture_option_payload(state, include_use_remesh=False):
    payload = {
        "face_count": int(state.texture_face_limit),
    }

    if state.launch_backend == "BACKEND_21":
        payload["max_num_view"] = int(state.texture_max_views)
        payload["texture_resolution"] = int(state.texture_resolution)
        if include_use_remesh:
            payload["use_remesh"] = bool(state.texture_use_remesh)
    else:
        payload["texture_resolution"] = int(state.texture_resolution_2mv)

    return payload


def _summarize_server_info(info):
    status = info.get("status", "unknown")
    model_path = info.get("model_path", "unknown")
    subfolder = info.get("subfolder", "unknown")
    capabilities = _server_capabilities_from_info(info)
    return (
        f"{status} | {model_path} | {subfolder} | "
        f"shape={capabilities['shape']} | tex={capabilities['texture']} | "
        f"retexture={capabilities['retexture']} | mv={capabilities['multiview']} | "
        f"text={capabilities['text']}"
    )


def _backend_family(info):
    blob = f"{info.get('model_path', '')} {info.get('subfolder', '')}".lower()
    if "2.1" in blob:
        return "2.1"
    if "2mv" in blob or "mv" in blob:
        return "2mv"
    if "hunyuan3d-2" in blob:
        return "2.0"
    return "Unknown"


def _server_capabilities_from_info(info):
    family = _backend_family(info)
    texture_only = bool(info.get("texture_only", False))
    text_enabled = bool(info.get("enable_t23d", False))
    retexture_enabled = bool(info.get("mesh_retexture", False))

    if family in {"2mv", "2.0"}:
        texture_enabled = bool(info.get("enable_tex", False))
        if not retexture_enabled:
            retexture_enabled = texture_enabled
        return {
            "family": family,
            "shape": not texture_only,
            "texture": texture_enabled,
            "retexture": retexture_enabled,
            "multiview": True,
            "text": text_enabled,
            "texture_only": texture_only,
        }

    if family == "2.1":
        texture_enabled = bool(info.get("enable_tex", True))
        return {
            "family": family,
            "shape": not texture_only,
            "texture": texture_enabled,
            "retexture": retexture_enabled,
            "multiview": False,
            "text": text_enabled,
            "texture_only": texture_only,
        }

    return {
        "family": family,
        "shape": not texture_only,
        "texture": False,
        "retexture": retexture_enabled,
        "multiview": False,
        "text": text_enabled,
        "texture_only": texture_only,
    }


def _fallback_server_capabilities(state):
    family = "2.1" if state.launch_backend == "BACKEND_21" else "2mv"
    if family == "2.1":
        texture_only = _launch_21_texture_only(state)
        texture_enabled = _launch_21_texture_enabled(state)
        return {
            "family": family,
            "shape": not texture_only,
            "texture": texture_enabled,
            "retexture": texture_enabled,
            "multiview": False,
            "text": bool(state.launch_text_bridge) and not texture_only,
            "texture_only": texture_only,
        }
    return {
        "family": family,
        "shape": True,
        "texture": bool(state.launch_texture_support),
        "retexture": bool(state.launch_texture_support),
        "multiview": True,
        "text": bool(state.launch_text_bridge),
        "texture_only": False,
    }


def _preferred_texture_mesh_format(state, caps):
    if caps["family"] == "2.1" and (caps["texture_only"] or _launch_21_texture_only(state)):
        return "obj"
    return "glb"


def _state_server_capabilities(state):
    capabilities = {
        "family": state.backend_family,
        "shape": bool(state.server_supports_shape),
        "texture": bool(state.server_supports_texture),
        "retexture": bool(state.server_supports_retexture),
        "multiview": bool(state.server_supports_multiview),
        "text": bool(state.server_supports_text),
        "texture_only": bool(state.server_texture_only),
    }
    if state.backend_summary in {"Unavailable", "Not checked", ""} and state.launch_state in {"Launching", "Running"}:
        return _fallback_server_capabilities(state)
    if capabilities["family"] == "Unknown" and state.launch_state in {"Launching", "Running"}:
        return _fallback_server_capabilities(state)
    return capabilities


def _normalized_panel_text(text):
    return " ".join((text or "").strip().lower().split())


def _scroll_text(text, window=42, step_seconds=0.6, gap="   "):
    cleaned = (text or "").strip()
    if len(cleaned) <= window:
        return cleaned
    cycle = cleaned + gap
    offset = int(time.monotonic() / step_seconds) % len(cycle)
    wrapped = cycle + cleaned + gap
    return wrapped[offset:offset + window]


def _is_hidden_stage(stage):
    normalized = (stage or "").strip().lower()
    return normalized in {
        "",
        "completed",
        "job complete",
        "server boot complete",
        "server ready",
        "starting server",
        "launch requested",
    }


def _progress_lines(state):
    active_status = (state.task_status or "").lower()
    has_live_task = active_status in {"processing", "queued"}
    if not state.is_busy and not has_live_task:
        return "", "", ""
    if state.waiting_for_backend_progress:
        return (
            "Request Sent",
            "Waiting for backend progress...",
            "",
        )
    if active_status not in {"processing", "queued"}:
        if state.is_busy:
            return (
                "Request Sent",
                "Waiting for backend progress...",
                "",
            )
        return "", "", ""
    stage = (state.task_stage or "").strip()
    detail = (state.task_detail or state.task_message or "").strip()
    progress = (state.task_progress or "").strip()
    if _is_hidden_stage(stage):
        return (
            "Request Sent",
            "Waiting for backend progress...",
            "",
        )
    return (
        stage or "Working",
        detail,
        progress,
    )


def _server_panel_job_lines(state):
    if state.launch_state == "Launching":
        return (
            state.task_stage or "Launch Requested",
            state.launch_detail or "Waiting for backend startup...",
            state.task_progress or "",
        )
    if state.launch_state == "Stopping":
        return ("Stopping", state.launch_detail or "Stopping backend...", "")
    if state.waiting_for_backend_progress:
        return "Request Sent", "Waiting for backend progress...", ""
    lines = _progress_lines(state)
    if any(lines):
        return lines
    if state.is_busy:
        return "Request Sent", "Waiting for backend progress...", ""
    return "", "", ""


def _server_status_line(state):
    backend_label = state.backend_family
    if backend_label == "Unknown":
        backend_label = "2.1" if state.launch_backend == "BACKEND_21" else "2mv"
    active_status = (state.task_status or "").lower()
    if state.launch_state == "Launching":
        return f"{backend_label} Launching"
    if state.launch_state == "Stopping":
        return "Stopping"
    if active_status == "processing":
        return f"{backend_label} Busy"
    if active_status == "queued" or state.waiting_for_backend_progress:
        return f"{backend_label} Submitting"
    if state.backend_summary not in {"Unavailable", "Not checked", ""} and state.launch_state not in {
        "Launching",
        "Stopping",
    }:
        return f"{backend_label} Ready"
    if state.backend_summary not in {"Unavailable", "Not checked", ""}:
        return f"{backend_label} Available"
    return "Server stopped"


def _current_vram_estimate(state):
    backend = "2.1" if state.launch_backend == "BACKEND_21" else "2mv"
    flashvdm = bool(state.launch_flashvdm)
    turbo = bool(state.launch_turbo)
    low_vram = bool(state.launch_low_vram)
    if state.shape_workflow == "TEXT" and state.prompt.strip():
        input_mode = "text_prompt"
    elif state.shape_workflow == "MULTIVIEW":
        input_mode = "multiview"
    else:
        input_mode = "single_image"

    if backend == "2.1":
        if _launch_21_texture_only(state):
            estimate = "21 GB"
            basis = "Basis: official"
            mode = "Texture only"
            caveat = (
                "Low VRAM may help fit, but the official texture figure is still 21 GB."
                if low_vram
                else "Official 2.1 texture figure."
            )
            return estimate, basis, mode, caveat
        texture_enabled = _launch_21_texture_enabled(state)
        if texture_enabled and state.shape_generate_texture:
            estimate = "29 GB total"
            basis = "Basis: official"
            mode = "Shape + texture"
            caveat = (
                "Low VRAM may help fit; no exact official replacement figure."
                if low_vram
                else "Low VRAM is recommended on 16 GB GPUs."
            )
            return estimate, basis, mode, caveat
        if input_mode == "text_prompt":
            estimate = "10-12 GB"
            basis = "Basis: official + inferred"
            mode = "Shape + text bridge"
            caveat = (
                "Low VRAM may help fit; bridge overhead is not separately published."
                if low_vram
                else "10 GB shape is official; bridge overhead is inferred."
            )
            return estimate, basis, mode, caveat
        estimate = "10 GB"
        basis = "Basis: official"
        mode = "Shape only"
        caveat = (
            "Low VRAM may reduce pressure, but no exact official number is published."
            if low_vram
            else "Official 2.1 shape figure."
        )
        return estimate, basis, mode, caveat

    texture = bool(state.launch_texture_support or state.shape_generate_texture)
    if texture:
        estimate = "16-24.5 GB total"
        basis = "Basis: official + inferred"
        mode = "Shape + texture"
        caveat = (
            "FlashVDM helps throughput, but texture mode still needs the larger VRAM budget."
            if flashvdm
            else "Texture mode is the main VRAM driver on 2mv."
        )
        return estimate, basis, mode, caveat
    if input_mode == "text_prompt":
        estimate = "10-12 GB"
        basis = "Basis: inferred"
        mode = "Shape + text bridge"
        caveat = "2mv text bridge overhead is inferred from mixed workflow usage."
        return estimate, basis, mode, caveat
    estimate = "9-12 GB"
    basis = "Basis: inferred"
    mode = "Shape only"
    caveat = "Turbo improves latency more than VRAM footprint." if turbo else "Standard 2mv shape mode."
    return estimate, basis, mode, caveat


def _active_task_snapshot(api_root):
    try:
        status_code, _, body = _http_call("GET", f"{api_root}/active_task", timeout=1.5)
        if status_code == 404:
            return {
                "status": "unsupported",
                "stage": "",
                "detail": "",
                "progress_text": "",
                "message": "",
            }
        data = json.loads(body.decode("utf-8"))
    except Exception:
        return {
            "status": "unavailable",
            "stage": "",
            "detail": "",
            "progress_text": "",
            "message": "",
        }

    stage = data.get("stage") or ""
    detail = data.get("detail") or data.get("message") or ""
    message = data.get("message") or ""

    return {
        "status": data.get("status", "idle"),
        "stage": _stage_label(stage),
        "detail": detail,
        "progress_text": _format_progress_text(
            current=data.get("progress_current"),
            total=data.get("progress_total"),
            percent=data.get("progress_percent"),
        ),
        "message": message,
    }


def _managed_backend():
    with PROCESS_LOCK:
        return MANAGED_BACKEND


def _managed_backend_target():
    with PROCESS_LOCK:
        return MANAGED_BACKEND_TARGET


def _remember_backend(proc, target=None):
    global MANAGED_BACKEND, MANAGED_BACKEND_TARGET
    with PROCESS_LOCK:
        MANAGED_BACKEND = proc
        MANAGED_BACKEND_TARGET = dict(target or {})


def _forget_backend(proc=None):
    global MANAGED_BACKEND, MANAGED_BACKEND_TARGET
    with PROCESS_LOCK:
        if proc is None or MANAGED_BACKEND is proc:
            MANAGED_BACKEND = None
            MANAGED_BACKEND_TARGET = None


def _backend_is_alive():
    proc = _managed_backend()
    return proc is not None and proc.poll() is None


def _shutdown_managed_backend():
    proc = _managed_backend()
    target = _managed_backend_target()
    if proc is not None and proc.poll() is None:
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        finally:
            _forget_backend(proc)

    # Keep the broad WSL cleanup path so a detached child server does not outlive Blender.
    stop_port = (target or {}).get("port", "8080")
    _best_effort_stop_local(stop_port, target)


def _sync_local_api(state):
    port = (state.launch_port or "8080").strip() or "8080"
    state.api_root = f"http://127.0.0.1:{port}"


def _probe_gpu_host():
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,memory.total,memory.used,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=2,
            check=True,
        )
        row = result.stdout.strip().splitlines()[0]
        name, mem_total, mem_used, util = [part.strip() for part in row.split(",")]
        return {
            "name": name,
            "memory": f"{mem_used} / {mem_total} MB",
            "utilization": f"{util}%",
            "status": "Connected",
        }
    except Exception as exc:
        return {
            "name": "Unavailable",
            "memory": "Unavailable",
            "utilization": "Unavailable",
            "status": str(exc),
        }


def _shell_repo_path(raw_path):
    path = (raw_path or "").strip()
    if not path:
        return "~"
    if path.startswith("~/"):
        suffix = path[2:]
        if not suffix:
            return "$HOME"
        return f"$HOME/{shlex.quote(suffix)}"
    return shlex.quote(path)


def _installed_wsl_distro_items():
    names = []
    try:
        result = subprocess.run(
            ["wsl", "-l", "-q"],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                name = line.replace("\0", "").strip()
                if name:
                    names.append(name)
    except Exception:
        pass

    ordered = []
    seen = set()
    for candidate in [DEFAULT_WSL_DISTRO, *names]:
        name = (candidate or "").strip()
        if not name:
            continue
        lowered = name.lower()
        if lowered in seen:
            continue
        seen.add(lowered)
        description = (
            "Managed installer distro"
            if name == DEFAULT_WSL_DISTRO
            else f"Use installed WSL distro '{name}'"
        )
        ordered.append((name, name, description))

    if not ordered:
        ordered.append((DEFAULT_WSL_DISTRO, DEFAULT_WSL_DISTRO, "Managed installer distro"))

    WSL_DISTRO_ITEMS[:] = ordered
    return WSL_DISTRO_ITEMS


def _wsl_distro_items(_self, _context):
    return _installed_wsl_distro_items()


def _resolved_wsl_distro_name(state=None):
    if isinstance(state, dict):
        value = (state.get("wsl_distro_name", DEFAULT_WSL_DISTRO) or "").strip()
        return value or DEFAULT_WSL_DISTRO
    if state is None:
        return DEFAULT_WSL_DISTRO
    value = (getattr(state, "wsl_distro_name", DEFAULT_WSL_DISTRO) or "").strip()
    return value or DEFAULT_WSL_DISTRO


def _resolved_wsl_user_name(state=None):
    if isinstance(state, dict):
        value = (state.get("wsl_user_name", DEFAULT_WSL_USER) or "").strip()
        return value or DEFAULT_WSL_USER
    if state is None:
        return DEFAULT_WSL_USER
    value = (getattr(state, "wsl_user_name", DEFAULT_WSL_USER) or "").strip()
    return value or DEFAULT_WSL_USER


def _compose_wsl_invocation(shell, state=None):
    command = ["wsl", "-d", _resolved_wsl_distro_name(state)]
    user_name = _resolved_wsl_user_name(state)
    if user_name:
        command.extend(["-u", user_name])
    command.extend(["--", "bash", "-lc", shell])
    return command


def _compose_wsl_launch(state):
    port = (state.launch_port or "8080").strip() or "8080"
    exports = (
        "export CUDA_HOME=/usr/local/cuda-13.0; "
        'export PATH="$CUDA_HOME/bin:$PATH"; '
        'export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"; '
    )

    if state.launch_backend == "BACKEND_21":
        repo_path = state.repo_21_path.strip() or DEFAULT_REPO_21_PATH
        texture_enabled = _launch_21_texture_enabled(state)
        texture_only = _launch_21_texture_only(state)
        parts = [
            "python",
            "-u",
            "api_server_tex.py" if texture_only else "api_server.py",
            "--host",
            "0.0.0.0",
            "--port",
            port,
            "--model_path",
            "tencent/Hunyuan3D-2.1",
            "--subfolder",
            "hunyuan3d-paintpbr-v2-1" if texture_only else "hunyuan3d-dit-v2-1",
        ]
        if not texture_only and not texture_enabled:
            parts.append("--disable_tex")
        if state.launch_text_bridge and not texture_only:
            parts.append("--enable_t23d")
        if state.launch_low_vram:
            parts.append("--low_vram_mode")
    else:
        repo_path = state.repo_2mv_path.strip() or DEFAULT_REPO_2MV_PATH
        subfolder = "hunyuan3d-dit-v2-mv-turbo" if state.launch_turbo else "hunyuan3d-dit-v2-mv"
        parts = [
            "python",
            "-u",
            "api_server_mv.py",
            "--host",
            "0.0.0.0",
            "--port",
            port,
            "--model_path",
            "tencent/Hunyuan3D-2mv",
            "--subfolder",
            subfolder,
            "--tex_model_path",
            "tencent/Hunyuan3D-2",
        ]
        if state.launch_texture_support:
            parts.append("--enable_tex")
        if state.launch_text_bridge:
            parts.append("--enable_t23d")
        if state.launch_flashvdm:
            parts.append("--enable_flashvdm")

    cmd = " ".join(shlex.quote(part) for part in parts)
    return f"{exports}cd {_shell_repo_path(repo_path)}; source .venv/bin/activate; {cmd}"


def _best_effort_stop_local(port, state=None):
    port = (port or "8080").strip() or "8080"
    shell = (
        f'(command -v fuser >/dev/null 2>&1 && fuser -k {port}/tcp >/dev/null 2>&1) || true; '
        'pkill -f "python -u api_server.py" >/dev/null 2>&1 || true; '
        'pkill -f "python -u api_server_tex.py" >/dev/null 2>&1 || true; '
        'pkill -f "python -u api_server_mv.py" >/dev/null 2>&1 || true; '
        'pkill -f "python api_server.py" >/dev/null 2>&1 || true; '
        'pkill -f "python api_server_tex.py" >/dev/null 2>&1 || true; '
        'pkill -f "python api_server_mv.py" >/dev/null 2>&1 || true'
    )
    try:
        subprocess.run(
            _compose_wsl_invocation(shell, state),
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except Exception:
        return False
    return True


def _startup_hint(line):
    cleaned = (line or "").replace("\r", "").strip()
    if not cleaned:
        return None
    cleaned = LOG_PREFIX_RE.sub("", cleaned).strip()
    if "Uvicorn running on http://" in cleaned or "Application startup complete." in cleaned:
        return "Server ready"

    stage_match = STAGE_LINE.search(cleaned)
    if stage_match:
        return stage_match.group(1).replace("_", " ").title()

    progress_match = PROGRESS_LINE.search(cleaned)
    if progress_match:
        label = progress_match.group(1).strip()
        return f"{label} {progress_match.group(2)}/{progress_match.group(3)}"

    for token in ("Loading", "FlashVDM", "Texture", "Diffusion Sampling", "Volume Decoding"):
        if token in cleaned:
            return cleaned[:120]
    return None


def _backend_stdout_pump(scene_name, proc):
    stream = proc.stdout
    if stream is None:
        return
    try:
        for raw_line in stream:
            if _managed_backend() is not proc:
                break
            hint = _startup_hint(raw_line)
            if not hint:
                continue
            if hint == "Server ready":
                _emit_status(
                    scene_name,
                    launch_state="Running",
                    launch_detail="Server ready",
                    status_text="Local backend is ready.",
                )
            else:
                _emit_status(scene_name, launch_detail=hint)
    except Exception:
        return


def _backend_lifecycle(scene_name, proc):
    exit_code = proc.wait()
    _forget_backend(proc)
    state = "Stopped"
    message = "Server stopped."
    if exit_code not in (0, -15):
        message = f"Server exited with code {exit_code}."
    _emit_status(
        scene_name,
        launch_state=state,
        launch_detail=message,
        backend_summary="Unavailable",
    )


def _background_server_probe(scene_name):
    state = _active_state(scene_name)
    if state is None:
        return
    api_root = _normalize_api_root(state.api_root)
    try:
        info = _json_call("GET", f"{api_root}/server_info", timeout=2)
        capabilities = _server_capabilities_from_info(info)
        _emit_status(
            scene_name,
            backend_summary=_summarize_server_info(info),
            backend_family=capabilities["family"],
            server_supports_shape=capabilities["shape"],
            server_supports_texture=capabilities["texture"],
            server_supports_retexture=capabilities["retexture"],
            server_supports_multiview=capabilities["multiview"],
            server_supports_text=capabilities["text"],
            server_texture_only=capabilities["texture_only"],
            launch_state="Running" if state.launch_state != "Stopping" else state.launch_state,
            launch_detail="Server ready",
        )
    except Exception as exc:
        changes = {
            "backend_summary": "Unavailable",
            "backend_family": "Unknown",
            "server_supports_shape": False,
            "server_supports_texture": False,
            "server_supports_retexture": False,
            "server_supports_multiview": False,
            "server_supports_text": False,
            "server_texture_only": False,
        }
        if state.launch_state == "Launching" and _backend_is_alive():
            changes["launch_detail"] = f"Waiting for /server_info at {api_root}"
            changes["status_text"] = f"Launch probe: {exc}"
        _emit_status(scene_name, **changes)


def _background_active_probe(scene_name):
    state = _active_state(scene_name)
    if state is None:
        return
    api_root = _normalize_api_root(state.api_root)
    snapshot = _active_task_snapshot(api_root)
    status = (snapshot.get("status") or "").lower()
    stage = snapshot.get("stage") or ""
    detail = snapshot.get("detail") or ""
    progress_text = snapshot.get("progress_text") or ""
    message = snapshot.get("message") or ""

    if status == "completed":
        changes = {
            "task_status": "idle",
            "task_stage": "",
            "task_detail": "",
            "task_progress": "",
            "task_message": "",
        }
        if not state.is_busy:
            changes["waiting_for_backend_progress"] = False
            changes["saw_real_backend_progress"] = False
        _emit_status(scene_name, **changes)
        return

    if state.is_busy and state.waiting_for_backend_progress:
        real_progress_arrived = (
            status == "processing"
            and not _is_hidden_stage(stage)
            and (bool(stage) or bool(detail) or bool(progress_text))
        )
        if not real_progress_arrived:
            return
        _emit_status(
            scene_name,
            waiting_for_backend_progress=False,
            saw_real_backend_progress=True,
        )

    if status not in {"processing", "queued"} or _is_hidden_stage(stage):
        if not state.is_busy:
            _emit_status(
                scene_name,
                task_status="idle",
                task_stage="",
                task_detail="",
                task_progress="",
                task_message="",
            )
        return

    _emit_status(
        scene_name,
        task_status=status,
        task_stage=stage,
        task_detail=detail,
        task_progress=progress_text,
        task_message=message,
    )


def _server_probe_timer():
    interval = SERVER_POLL_SECONDS
    for scene in bpy.data.scenes:
        state = getattr(scene, "nymphs3d2v2_state", None)
        if state is None:
            continue
        threading.Thread(target=_background_server_probe, args=(scene.name,), daemon=True).start()
        if state.launch_state in {"Launching", "Stopping"}:
            interval = SERVER_POLL_FAST_SECONDS
        break
    return interval


def _active_probe_timer():
    interval = ACTIVE_POLL_IDLE_SECONDS
    for scene in bpy.data.scenes:
        state = getattr(scene, "nymphs3d2v2_state", None)
        if state is None:
            continue
        threading.Thread(target=_background_active_probe, args=(scene.name,), daemon=True).start()
        status = (state.task_status or "").lower()
        if state.is_busy:
            interval = ACTIVE_POLL_DIRECT_JOB_SECONDS
        elif status in {"processing", "queued"}:
            interval = ACTIVE_POLL_BUSY_SECONDS
        elif status in {"unsupported", "unavailable"}:
            interval = ACTIVE_POLL_UNAVAILABLE_SECONDS
        break
    return interval


def _gpu_probe_timer():
    for scene in bpy.data.scenes:
        state = getattr(scene, "nymphs3d2v2_state", None)
        if state is None:
            continue
        stats = _probe_gpu_host()
        state.gpu_name = stats["name"]
        state.gpu_memory = stats["memory"]
        state.gpu_utilization = stats["utilization"]
        state.gpu_status_message = stats["status"]
        break
    return GPU_REFRESH_SECONDS


def _import_result(event):
    before_names = set(bpy.data.objects.keys())
    bpy.ops.import_scene.gltf(filepath=event.mesh_path)
    imported_names = [name for name in bpy.data.objects.keys() if name not in before_names]

    if event.source_object_name and imported_names:
        source_object = bpy.data.objects.get(event.source_object_name)
        imported_object = bpy.data.objects.get(imported_names[0])
        if source_object is not None and imported_object is not None:
            imported_object.location = source_object.location
            imported_object.rotation_euler = source_object.rotation_euler
            imported_object.scale = source_object.scale
            source_object.hide_set(True)
            source_object.hide_render = True

    try:
        os.unlink(event.mesh_path)
    except OSError:
        pass

    state = _active_state(event.scene_name)
    if state is not None:
        state.is_busy = False
        state.task_status = "idle"
        state.task_stage = ""
        state.task_detail = ""
        state.task_progress = ""
        state.task_message = ""
        state.waiting_for_backend_progress = False
        state.saw_real_backend_progress = False
        state.generation_request_finished_locally = True
        state.status_text = "Mesh imported into Blender."
        state.last_result = "Imported latest result"


def _job_worker(scene_name, api_root, payload, source_object_name):
    try:
        _, content_type, body = _http_call(
            "POST",
            f"{api_root}/generate",
            payload=payload,
            timeout=1800,
        )
        if "json" in (content_type or "").lower():
            try:
                detail = json.loads(body.decode("utf-8"))
            except Exception:
                detail = body.decode("utf-8", errors="replace")
            raise RuntimeError(f"Expected mesh bytes, got JSON: {detail}")

        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".glb")
        temp_file.write(body)
        temp_file.close()

        _emit_status(scene_name, status_text="Generation finished. Importing result...")
        _emit_import(scene_name, temp_file.name, source_object_name)
    except Exception as exc:
        _emit_status(
            scene_name,
            is_busy=False,
            task_status="idle",
            task_stage="",
            task_detail="",
            task_progress="",
            task_message="",
            waiting_for_backend_progress=False,
            saw_real_backend_progress=False,
            generation_request_finished_locally=False,
            status_text=str(exc),
        )


class NymphsV2State(bpy.types.PropertyGroup):
    api_root: StringProperty(
        name="API URL",
        description="URL of the Nymphs3D backend API",
        default="http://127.0.0.1:8080",
    )
    launch_backend: EnumProperty(
        name="Backend",
        items=(
            ("BACKEND_2MV", "2mv", "Launch the multiview Hunyuan backend"),
            ("BACKEND_21", "2.1", "Launch the newer single-image backend"),
        ),
        default="BACKEND_2MV",
    )
    launch_shape_support: BoolProperty(
        name="Shape",
        default=True,
    )
    launch_texture_support: BoolProperty(
        name="Texture",
        default=True,
    )
    launch_texture_only: BoolProperty(
        name="Texture-Only Server",
        default=False,
        update=_on_launch_texture_only_changed,
    )
    launch_text_bridge: BoolProperty(
        name="Text Prompt Support",
        default=False,
    )
    launch_turbo: BoolProperty(
        name="Turbo",
        default=True,
    )
    launch_flashvdm: BoolProperty(
        name="FlashVDM",
        default=True,
    )
    launch_low_vram: BoolProperty(
        name="Low VRAM",
        default=True,
    )
    launch_open_terminal: BoolProperty(
        name="Open Terminal Window",
        default=False,
    )
    launch_port: StringProperty(
        name="Port",
        default="8080",
    )
    wsl_distro_name: EnumProperty(
        name="WSL Distro",
        description="Which installed WSL distro to target for local backend launch",
        items=_wsl_distro_items,
    )
    wsl_user_name: StringProperty(
        name="WSL User",
        description="Which Linux user to use inside the selected WSL distro",
        default=DEFAULT_WSL_USER,
    )
    repo_2mv_path: StringProperty(
        name="2mv Path",
        default=DEFAULT_REPO_2MV_PATH,
    )
    repo_21_path: StringProperty(
        name="2.1 Path",
        default=DEFAULT_REPO_21_PATH,
    )
    shape_workflow: EnumProperty(
        name="Shape Workflow",
        items=(
            ("IMAGE", "Image to 3D", "Generate shape from one image"),
            ("MULTIVIEW", "Multiview to 3D", "Generate shape from front/back/left/right images"),
            ("TEXT", "Text to 3D", "Generate shape from a text prompt"),
        ),
        default="IMAGE",
    )
    prompt: StringProperty(
        name="Prompt",
        description="Optional text prompt or text-only request",
        default="",
    )
    image_path: StringProperty(
        name="Image",
        description="Source image for image or retexture workflows",
        subtype="FILE_PATH",
        default="",
    )
    mv_front: StringProperty(name="Front", subtype="FILE_PATH", default="")
    mv_back: StringProperty(name="Back", subtype="FILE_PATH", default="")
    mv_left: StringProperty(name="Left", subtype="FILE_PATH", default="")
    mv_right: StringProperty(name="Right", subtype="FILE_PATH", default="")
    auto_remove_background: BoolProperty(
        name="Auto Remove Background",
        default=True,
    )
    mesh_detail: IntProperty(
        name="Mesh Detail",
        default=256,
        min=128,
        max=512,
    )
    detail_passes: IntProperty(
        name="Detail Passes",
        default=20,
        min=10,
        max=100,
    )
    reference_strength: FloatProperty(
        name="Reference Strength",
        default=5.5,
        min=1.0,
        max=12.0,
    )
    shape_generate_texture: BoolProperty(
        name="Also Generate Texture",
        default=True,
    )
    texture_face_limit: IntProperty(
        name="Face Limit",
        default=40000,
        min=1000,
        max=100000,
    )
    texture_max_views: IntProperty(
        name="Max Views",
        default=6,
        min=6,
        max=12,
    )
    texture_resolution: EnumProperty(
        name="Texture Size",
        items=(
            ("512", "512 px", "Lower VRAM and faster texture synthesis"),
            ("768", "768 px", "Higher quality but heavier texture synthesis"),
        ),
        default="512",
    )
    texture_resolution_2mv: EnumProperty(
        name="Texture Size",
        items=(
            ("512", "512 px", "Lowest VRAM and fastest 2mv texturing"),
            ("1024", "1024 px", "Lower VRAM and faster 2mv texturing"),
            ("2048", "2048 px", "Higher quality but heavier 2mv texturing"),
        ),
        default="2048",
    )
    texture_use_remesh: BoolProperty(
        name="Remesh Uploaded Mesh",
        description="Experimental. Rebuild the uploaded mesh before texturing. Can help some meshes but may damage others.",
        default=False,
    )
    show_controls: BoolProperty(default=True)
    show_startup: BoolProperty(default=True)
    show_texture_settings: BoolProperty(default=False)
    show_details: BoolProperty(default=False)
    show_gpu: BoolProperty(default=True)
    show_advanced: BoolProperty(default=False)
    show_shape: BoolProperty(default=True)
    show_texture: BoolProperty(default=True)
    is_busy: BoolProperty(default=False)
    status_text: StringProperty(
        name="Status",
        default="Idle",
    )
    backend_summary: StringProperty(
        name="Backend Summary",
        default="Not checked",
    )
    gpu_summary: StringProperty(
        name="GPU Summary",
        default="Not checked",
    )
    gpu_name: StringProperty(name="GPU Name", default="Unknown")
    gpu_memory: StringProperty(name="GPU Memory", default="Unavailable")
    gpu_utilization: StringProperty(name="GPU Utilization", default="Unavailable")
    gpu_status_message: StringProperty(name="GPU Status", default="Not checked")
    launch_state: StringProperty(
        name="Launch State",
        default="Stopped",
    )
    launch_detail: StringProperty(
        name="Launch Detail",
        default="No local backend launched from Blender.",
    )
    backend_family: StringProperty(default="Unknown")
    server_supports_shape: BoolProperty(default=False)
    server_supports_texture: BoolProperty(default=False)
    server_supports_retexture: BoolProperty(default=False)
    server_supports_multiview: BoolProperty(default=False)
    server_supports_text: BoolProperty(default=False)
    server_texture_only: BoolProperty(default=False)
    task_status: StringProperty(default="idle")
    task_stage: StringProperty(default="")
    task_detail: StringProperty(default="")
    task_progress: StringProperty(default="")
    task_message: StringProperty(default="")
    waiting_for_backend_progress: BoolProperty(default=False)
    saw_real_backend_progress: BoolProperty(default=False)
    generation_request_finished_locally: BoolProperty(default=False)
    last_result: StringProperty(
        name="Last Result",
        default="",
    )


class NYMPHSV2_OT_probe_backend(bpy.types.Operator):
    bl_idname = "nymphsv2.probe_backend"
    bl_label = "Probe Backend"
    bl_description = "Fetch /server_info from the configured backend"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        try:
            api_root = _normalize_api_root(state.api_root)
            _require_network_access(api_root)
            info = _json_call("GET", f"{api_root}/server_info", timeout=4)
            capabilities = _server_capabilities_from_info(info)
            state.backend_summary = _summarize_server_info(info)
            state.backend_family = capabilities["family"]
            state.server_supports_shape = capabilities["shape"]
            state.server_supports_texture = capabilities["texture"]
            state.server_supports_retexture = capabilities["retexture"]
            state.server_supports_multiview = capabilities["multiview"]
            state.server_supports_text = capabilities["text"]
            state.server_texture_only = capabilities["texture_only"]
            _sync_shape_texture_state(state)
            state.launch_detail = "Server probe succeeded."
            state.status_text = "Backend probe succeeded."
        except Exception as exc:
            state.backend_summary = "Unavailable"
            state.backend_family = "Unknown"
            state.server_supports_shape = False
            state.server_supports_texture = False
            state.server_supports_retexture = False
            state.server_supports_multiview = False
            state.server_supports_text = False
            state.server_texture_only = False
            _sync_shape_texture_state(state)
            state.status_text = str(exc)
            return {"CANCELLED"}
        return {"FINISHED"}


class NYMPHSV2_OT_probe_gpu(bpy.types.Operator):
    bl_idname = "nymphsv2.probe_gpu"
    bl_label = "Refresh GPU"
    bl_description = "Probe host GPU usage with nvidia-smi"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        stats = _probe_gpu_host()
        state.gpu_name = stats["name"]
        state.gpu_memory = stats["memory"]
        state.gpu_utilization = stats["utilization"]
        state.gpu_status_message = stats["status"]
        state.status_text = "GPU probe finished."
        return {"FINISHED"}


class NYMPHSV2_OT_start_backend(bpy.types.Operator):
    bl_idname = "nymphsv2.start_backend"
    bl_label = "Start Server"
    bl_description = "Launch the local WSL backend from Blender"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        if _backend_is_alive():
            state.status_text = "A managed backend is already running."
            return {"CANCELLED"}

        _sync_local_api(state)
        shell = _compose_wsl_launch(state)

        try:
            _best_effort_stop_local(state.launch_port, state)
            popen_kwargs = {
                "text": True,
                "bufsize": 1,
            }
            if os.name == "nt":
                if state.launch_open_terminal:
                    popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
                    popen_kwargs["stdout"] = None
                    popen_kwargs["stderr"] = None
                else:
                    popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                    popen_kwargs["stdout"] = subprocess.PIPE
                    popen_kwargs["stderr"] = subprocess.STDOUT
            else:
                popen_kwargs["stdout"] = subprocess.PIPE
                popen_kwargs["stderr"] = subprocess.STDOUT

            proc = subprocess.Popen(_compose_wsl_invocation(shell, state), **popen_kwargs)
        except Exception as exc:
            state.launch_state = "Stopped"
            state.launch_detail = str(exc)
            state.status_text = f"Launch failed: {exc}"
            return {"CANCELLED"}

        _remember_backend(
            proc,
            {
                "port": (state.launch_port or "8080").strip() or "8080",
                "wsl_distro_name": _resolved_wsl_distro_name(state),
                "wsl_user_name": _resolved_wsl_user_name(state),
            },
        )
        state.launch_state = "Launching"
        state.launch_detail = "Starting local WSL backend..."
        state.status_text = "Launch requested."
        state.backend_summary = "Waiting for /server_info..."

        if proc.stdout is not None:
            threading.Thread(
                target=_backend_stdout_pump,
                args=(context.scene.name, proc),
                daemon=True,
            ).start()
        threading.Thread(
            target=_backend_lifecycle,
            args=(context.scene.name, proc),
            daemon=True,
        ).start()
        _schedule_event_loop()
        return {"FINISHED"}


class NYMPHSV2_OT_stop_backend(bpy.types.Operator):
    bl_idname = "nymphsv2.stop_backend"
    bl_label = "Stop Server"
    bl_description = "Stop the managed local WSL backend"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        proc = _managed_backend()
        if proc is None or proc.poll() is not None:
            _best_effort_stop_local(state.launch_port, state)
            state.launch_state = "Stopped"
            state.launch_detail = "No managed backend was running."
            state.status_text = "No managed backend was running."
            return {"CANCELLED"}
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except Exception as exc:
                state.status_text = f"Stop failed: {exc}"
                return {"CANCELLED"}

        _best_effort_stop_local(state.launch_port, state)
        state.launch_state = "Stopping"
        state.launch_detail = "Stopping local backend..."
        state.status_text = "Stop requested."
        _schedule_event_loop()
        return {"FINISHED"}


def _submit_request(context, state, payload, source_name, status_text):
    api_root = _normalize_api_root(state.api_root)
    state.is_busy = True
    state.status_text = status_text
    state.last_result = ""
    state.generation_request_finished_locally = False
    state.task_status = "queued"
    state.task_stage = "Request Sent"
    state.task_detail = "Waiting for backend progress..."
    state.task_progress = ""
    state.task_message = ""
    state.waiting_for_backend_progress = True
    state.saw_real_backend_progress = False
    _touch_ui()

    worker = threading.Thread(
        target=_job_worker,
        args=(context.scene.name, api_root, payload, source_name),
        daemon=True,
    )
    worker.start()
    _schedule_event_loop()


class NYMPHSV2_OT_run_shape_request(bpy.types.Operator):
    bl_idname = "nymphsv2.run_shape_request"
    bl_label = "Generate Shape"
    bl_description = "Send the current shape request to the backend and import the result"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        if state.is_busy:
            self.report({"WARNING"}, "A request is already running.")
            return {"CANCELLED"}

        caps = _state_server_capabilities(state)
        texture_requested = bool(state.shape_generate_texture and caps["texture"])
        if not caps["shape"] or caps["texture_only"]:
            self.report({"ERROR"}, "The current server is not exposing shape generation.")
            return {"CANCELLED"}
        if state.shape_workflow == "MULTIVIEW" and not caps["multiview"]:
            self.report({"ERROR"}, "The current server does not support multiview shape generation.")
            return {"CANCELLED"}
        if state.shape_workflow == "TEXT" and not caps["text"]:
            self.report({"ERROR"}, "The current server was not started with text support.")
            return {"CANCELLED"}

        try:
            api_root = _normalize_api_root(state.api_root)
            _require_network_access(api_root)
            payload = _build_shape_payload(state)
            payload["texture"] = texture_requested
            if texture_requested:
                payload.update(_texture_option_payload(state))
        except Exception as exc:
            state.status_text = str(exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        if state.shape_workflow == "MULTIVIEW":
            status_text = "Submitting multiview shape request..."
            if texture_requested:
                status_text = "Submitting multiview shape + texture request..."
        elif state.shape_workflow == "TEXT":
            status_text = "Submitting text-to-3D request..."
            if texture_requested:
                status_text = "Submitting text-to-3D + texture request..."
        else:
            status_text = "Submitting image-to-3D request..."
            if texture_requested:
                status_text = "Submitting image-to-3D + texture request..."

        _submit_request(context, state, payload, "", status_text)
        return {"FINISHED"}


class NYMPHSV2_OT_run_texture_request(bpy.types.Operator):
    bl_idname = "nymphsv2.run_texture_request"
    bl_label = "Retexture Selected Mesh"
    bl_description = "Send the selected mesh to the backend texture path and import the result"

    def execute(self, context):
        state = context.scene.nymphs3d2v2_state
        if state.is_busy:
            self.report({"WARNING"}, "A request is already running.")
            return {"CANCELLED"}

        caps = _state_server_capabilities(state)
        if not caps["retexture"]:
            self.report({"ERROR"}, "The current server does not expose mesh retexturing.")
            return {"CANCELLED"}

        try:
            api_root = _normalize_api_root(state.api_root)
            _require_network_access(api_root)
            mesh_format = _preferred_texture_mesh_format(state, caps)
            mesh_b64, source_name = _export_selected_mesh_base64(context, export_format=mesh_format)
            payload = _build_texture_payload(state, mesh_b64=mesh_b64, mesh_format=mesh_format)
        except Exception as exc:
            state.status_text = str(exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        _submit_request(context, state, payload, source_name, "Texturing selected mesh...")
        return {"FINISHED"}


class NYMPHSV2_PT_server(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Nymphs3D"
    bl_label = "Nymphs Server"

    def draw(self, context):
        state = context.scene.nymphs3d2v2_state
        layout = self.layout

        top = layout.box()
        progress_stage, progress_detail, progress_value = _server_panel_job_lines(state)
        current_job = progress_stage or "Idle"
        current_detail = progress_detail or state.launch_detail
        if current_detail and progress_value and current_detail.strip() == progress_value.strip():
            current_detail = ""
        top.label(text=f"Status: {_server_status_line(state)}"[:160])
        top.label(text=f"Current Job: {current_job}"[:160])
        if current_detail:
            top.label(text=f"Detail: {_scroll_text(current_detail)}"[:160])
        if progress_value:
            top.label(text=f"Progress: {progress_value}"[:160])

        controls = layout.box()
        controls.prop(
            state,
            "show_controls",
            text="Controls",
            icon="TRIA_DOWN" if state.show_controls else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_controls:
            controls.prop(state, "api_root")
            wsl_target = controls.box()
            wsl_target.label(text="WSL Target")
            wsl_target.use_property_split = True
            wsl_target.use_property_decorate = False
            wsl_target.prop(state, "wsl_distro_name", text="Distro")
            wsl_target.prop(state, "wsl_user_name", text="User")
            controls.prop(state, "launch_open_terminal")
            row = controls.row(align=True)
            row.operator("nymphsv2.start_backend", text="Start Server")
            row.operator("nymphsv2.stop_backend", text="Stop Server")
            row = controls.row(align=True)
            row.operator("nymphsv2.probe_backend", text="Refresh Server")
            row.operator("nymphsv2.probe_gpu", text="Refresh GPU")

        startup = layout.box()
        startup.prop(
            state,
            "show_startup",
            text="Startup Settings",
            icon="TRIA_DOWN" if state.show_startup else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_startup:
            startup.prop(state, "launch_backend", expand=True)
            row = startup.row(align=True)
            if state.launch_backend == "BACKEND_2MV":
                row.prop(state, "launch_texture_support")
                row.prop(state, "launch_text_bridge")
                row = startup.row(align=True)
                row.prop(state, "launch_turbo")
                row.prop(state, "launch_flashvdm")
            else:
                tex_row = row.row(align=True)
                tex_row.enabled = not state.launch_texture_only
                tex_row.prop(state, "launch_texture_support")
                row.prop(state, "launch_texture_only")
                row = startup.row(align=True)
                text_row = row.row(align=True)
                text_row.enabled = not state.launch_texture_only
                text_row.prop(state, "launch_text_bridge")
                row.prop(state, "launch_low_vram")
                if state.launch_texture_only:
                    startup.label(text="Texture-only mode starts the dedicated 2.1 paint server.")

        advanced = layout.box()
        advanced.prop(
            state,
            "show_advanced",
            text="Advanced",
            icon="TRIA_DOWN" if state.show_advanced else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_advanced:
            advanced.prop(state, "launch_port")
            advanced.prop(state, "repo_2mv_path")
            advanced.prop(state, "repo_21_path")

        info = layout.box()
        info.prop(
            state,
            "show_details",
            text="Details",
            icon="TRIA_DOWN" if state.show_details else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_details:
            info.label(text=f"Managed: {'Yes' if _backend_is_alive() else 'No'}")
            info.label(text=f"Launch State: {state.launch_state}")
            info.label(text=f"Backend: {state.backend_summary}"[:160])
            info.label(text=f"Task Status: {state.task_status}"[:160])
            info.label(text=f"Task Stage: {state.task_stage}"[:160])
            if state.task_detail:
                info.label(text=f"Task Detail: {state.task_detail}"[:160])
            if state.task_progress:
                info.label(text=f"Task Progress: {state.task_progress}"[:160])
            estimate, basis, mode, caveat = _current_vram_estimate(state)
            info.separator()
            info.label(text=f"VRAM Estimate: {estimate}"[:160])
            info.label(text=f"VRAM Mode: {mode}"[:160])
            info.label(text=basis[:160])
            info.label(text=f"Caveat: {caveat}"[:160])

        gpu = layout.box()
        gpu.prop(
            state,
            "show_gpu",
            text="GPU",
            icon="TRIA_DOWN" if state.show_gpu else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_gpu:
            gpu.label(text=f"GPU: {state.gpu_name}"[:160])
            gpu.label(text=f"VRAM: {state.gpu_memory}"[:160])
            gpu.label(text=f"Load: {state.gpu_utilization}"[:160])
            gpu.label(text=f"Driver Status: {state.gpu_status_message}"[:160])


def _panel_status_text(state):
    if state.last_result:
        return state.last_result
    active_status = (state.task_status or "").lower()
    if state.is_busy or active_status in {"processing", "queued"}:
        if state.waiting_for_backend_progress or active_status == "queued":
            return "Submitting..."
        return "Running..."

    status_text = (state.status_text or "").strip()
    if not status_text:
        return "Ready"

    lowered = status_text.lower()
    passive_prefixes = (
        "submitting ",
        "launch ",
        "stop ",
        "backend probe",
        "gpu probe",
        "generation finished",
        "mesh imported",
        "local backend is ready",
    )
    passive_exact = {
        "Launch requested.",
        "Stop requested.",
        "Backend probe succeeded.",
        "GPU probe finished.",
        "Local backend is ready.",
        "No managed backend was running.",
        "A managed backend is already running.",
    }
    if status_text in passive_exact or lowered.startswith(passive_prefixes):
        return "Ready"

    return status_text


def _draw_request_status(panel, state):
    status = panel.box()
    status.label(text=f"Status: {_panel_status_text(state)}"[:160])
    if state.task_stage:
        stage_norm = _normalized_panel_text(state.task_stage)
        if stage_norm and stage_norm not in {"idle", "request sent"}:
            status.label(text=f"Current Job: {state.task_stage}"[:160])
    if state.last_result:
        status.label(text=state.last_result[:160])


class NYMPHSV2_PT_shape(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Nymphs3D"
    bl_label = "Nymphs3D2 Shape"

    def draw(self, context):
        state = context.scene.nymphs3d2v2_state
        layout = self.layout
        caps = _state_server_capabilities(state)
        texture_requested = bool(state.shape_generate_texture and caps["texture"])

        panel = layout.box()
        panel.prop(
            state,
            "show_shape",
            text="Shape Request",
            icon="TRIA_DOWN" if state.show_shape else "TRIA_RIGHT",
            emboss=False,
        )
        if not state.show_shape:
            return

        if state.backend_summary == "Unavailable" and not _backend_is_alive():
            warn = panel.box()
            warn.label(text="Server info is unavailable.")
            warn.label(text="Start the local server above.")

        if not caps["shape"] or caps["texture_only"]:
            warn = panel.box()
            warn.label(text="Current server is not exposing shape generation.")
            warn.label(text="Use a shape-capable backend instance.")
            panel.label(text=f"Status: {_panel_status_text(state)}"[:160])
            return

        request = panel.box()
        request.label(text="Workflow")
        request.prop(state, "shape_workflow")

        text_row = request.row()
        text_row.enabled = caps["text"] or state.shape_workflow != "TEXT"
        text_row.prop(state, "prompt")
        if state.shape_workflow == "TEXT" and not caps["text"]:
            request.label(text="This server was not started with text support.")

        if state.shape_workflow == "IMAGE":
            request.prop(state, "image_path")
        elif state.shape_workflow == "MULTIVIEW":
            if not caps["multiview"]:
                request.label(text="Current server does not expose multiview.")
            request.prop(state, "mv_front")
            request.prop(state, "mv_back")
            request.prop(state, "mv_left")
            request.prop(state, "mv_right")

        request.prop(state, "auto_remove_background")
        texture_row = request.row()
        texture_row.enabled = caps["texture"]
        texture_row.prop(state, "shape_generate_texture")
        if not caps["texture"]:
            request.label(text="This server was started without texture support.")
            if state.shape_generate_texture:
                request.label(text="Shape requests will run without texture on this server.")
        request.prop(state, "mesh_detail")
        request.prop(state, "detail_passes")
        request.prop(state, "reference_strength")

        action = panel.row()
        workflow_supported = True
        if state.shape_workflow == "MULTIVIEW" and not caps["multiview"]:
            workflow_supported = False
        if state.shape_workflow == "TEXT" and not caps["text"]:
            workflow_supported = False
        action.enabled = not state.is_busy and workflow_supported
        action.operator(
            "nymphsv2.run_shape_request",
            text="Generate Shape + Texture" if texture_requested else "Generate Shape",
        )

        _draw_request_status(panel, state)


class NYMPHSV2_PT_texture(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Nymphs3D"
    bl_label = "Nymphs3D2 Texture"

    def draw(self, context):
        state = context.scene.nymphs3d2v2_state
        layout = self.layout
        caps = _state_server_capabilities(state)

        panel = layout.box()
        panel.prop(
            state,
            "show_texture",
            text="Texture Request",
            icon="TRIA_DOWN" if state.show_texture else "TRIA_RIGHT",
            emboss=False,
        )
        if not state.show_texture:
            return

        info = panel.box()
        info.label(text="Retexture Selected Mesh")
        if not caps["texture"]:
            info.label(text="Current server does not expose texture generation.")
        elif not caps["retexture"]:
            info.label(text="Current server can texture generated shapes only.")
            info.label(text="Mesh retexturing is not exposed here yet.")
        elif caps["texture_only"]:
            info.label(text="Texture-only server mode is active.")

        request = panel.box()
        request.label(text="Texture Guidance")
        request.prop(state, "image_path")
        request.prop(state, "prompt")
        request.prop(state, "auto_remove_background")

        texture_opts = panel.box()
        texture_opts.prop(
            state,
            "show_texture_settings",
            text="Texture Options",
            icon="TRIA_DOWN" if state.show_texture_settings else "TRIA_RIGHT",
            emboss=False,
        )
        if state.show_texture_settings:
            texture_opts.prop(state, "texture_face_limit")
            active_family = caps["family"]
            if active_family == "Unknown":
                active_family = "2.1" if state.launch_backend == "BACKEND_21" else "2mv"

            if active_family == "2.1":
                texture_opts.prop(state, "texture_max_views")
                size_col = texture_opts.column(align=True)
                size_col.label(text="Texture Size")
                size_col.prop(state, "texture_resolution", text="")
                texture_opts.prop(state, "texture_use_remesh")
                texture_opts.label(text="2.1 options: Face Limit, Max Views, Texture Size, Remesh")
                if not state.texture_use_remesh:
                    texture_opts.label(text="Face Limit only applies when remesh is active.")
            else:
                texture_opts.label(text="2mv texture options: Face Limit, Texture Size")
                size_col = texture_opts.column(align=True)
                size_col.label(text="Texture Size")
                size_col.prop(state, "texture_resolution_2mv", text="")
                texture_opts.label(text="2mv speed/quality also lives in Startup: Texture, Turbo, FlashVDM")
                disabled = texture_opts.column(align=True)
                disabled.enabled = False
                disabled.prop(state, "texture_max_views")
                disabled.prop(state, "texture_use_remesh")
                texture_opts.label(text="The greyed controls above are 2.1-only.")

        action = panel.row()
        action.enabled = not state.is_busy and caps["retexture"]
        action.operator("nymphsv2.run_texture_request", text="Retexture Selected Mesh")

        _draw_request_status(panel, state)


CLASSES = (
    NymphsV2State,
    NYMPHSV2_OT_probe_backend,
    NYMPHSV2_OT_probe_gpu,
    NYMPHSV2_OT_start_backend,
    NYMPHSV2_OT_stop_backend,
    NYMPHSV2_OT_run_shape_request,
    NYMPHSV2_OT_run_texture_request,
    NYMPHSV2_PT_server,
    NYMPHSV2_PT_shape,
    NYMPHSV2_PT_texture,
)


def register():
    global ATEXIT_REGISTERED
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.nymphs3d2v2_state = PointerProperty(type=NymphsV2State)
    if not bpy.app.timers.is_registered(_server_probe_timer):
        bpy.app.timers.register(_server_probe_timer, persistent=True)
    if not bpy.app.timers.is_registered(_active_probe_timer):
        bpy.app.timers.register(_active_probe_timer, persistent=True)
    if not bpy.app.timers.is_registered(_gpu_probe_timer):
        bpy.app.timers.register(_gpu_probe_timer, persistent=True)
    if not ATEXIT_REGISTERED:
        atexit.register(_shutdown_managed_backend)
        ATEXIT_REGISTERED = True


def unregister():
    global ATEXIT_REGISTERED
    _shutdown_managed_backend()
    if bpy.app.timers.is_registered(_drain_events):
        bpy.app.timers.unregister(_drain_events)
    if bpy.app.timers.is_registered(_server_probe_timer):
        bpy.app.timers.unregister(_server_probe_timer)
    if bpy.app.timers.is_registered(_active_probe_timer):
        bpy.app.timers.unregister(_active_probe_timer)
    if bpy.app.timers.is_registered(_gpu_probe_timer):
        bpy.app.timers.unregister(_gpu_probe_timer)
    if ATEXIT_REGISTERED:
        try:
            atexit.unregister(_shutdown_managed_backend)
        except Exception:
            pass
        ATEXIT_REGISTERED = False
    del bpy.types.Scene.nymphs3d2v2_state
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
